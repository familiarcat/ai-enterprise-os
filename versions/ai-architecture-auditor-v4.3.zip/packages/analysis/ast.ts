
import { parse } from "@babel/parser"
import traverse from "@babel/traverse"

export function analyze(code){
  const ast = parse(code, { sourceType:"module", plugins:["jsx"] })
  const result = { imports:[], functions:0 }

  traverse(ast,{
    ImportDeclaration(p){ result.imports.push(p.node.source.value) },
    FunctionDeclaration(){ result.functions++ }
  })

  return result
}
