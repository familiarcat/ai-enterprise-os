
import { execSync } from "child_process"

export function cloneRepo(url){
  execSync(`git clone ${url} tmp_repo`)
  return "tmp_repo"
}
