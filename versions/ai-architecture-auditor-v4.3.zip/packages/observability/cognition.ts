
export const graph = { nodes: [], edges: [] }

export function addNode(id, type){
  graph.nodes.push({ id, type })
}

export function addEdge(from, to){
  graph.edges.push({ from, to })
}
