
import { runAgents } from "./core/execution/runner"
export async function runAudit(input){
  return runAgents(input)
}
