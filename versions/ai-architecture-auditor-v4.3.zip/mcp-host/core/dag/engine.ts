
export class DAG {
  constructor(nodes){ this.nodes = nodes }

  async run(agents, input){
    const results = {}

    for(const n of this.nodes){
      results[n.id] = await agents[n.agent].run(input)
    }

    return results
  }
