
import { runTool } from "../tools/registry"
import { addNode, addEdge } from "../../../packages/observability/cognition"

export class Agent {
  constructor(name){ this.name = name }

  async run(input){
    addNode(this.name,"agent")

    const result = await runTool("analyze_codebase", input)

    addNode("analyze_codebase","tool")
    addEdge(this.name,"analyze_codebase")

    return result
  }
}
