
import { Agent } from "./base"

export const agents = {
  analyzer: new Agent("analyzer")
}
