
import { DAG } from "../dag/engine"
import { agents } from "../agents"

export async function runAgents(input){
  const dag = new DAG([
    { id:"step1", agent:"analyzer" }
  ])
  return await dag.run(agents, input)
}
