
import codeAnalyzer from "../../../mcp-servers/code-analyzer/server"

export function getTools(){
  return [...codeAnalyzer.tools]
}

export async function runTool(name, args){
  const tool = getTools().find(t=>t.name===name)
  return tool.handler(args)
}
