
import fs from "fs"
import { cloneRepo } from "../../packages/github/clone"
import { analyze } from "../../packages/analysis/ast"

export default {
  tools: [
    {
      name: "analyze_codebase",
      handler: async ({ repoUrl }) => {
        const dir = cloneRepo(repoUrl)
        const files = fs.readdirSync(dir)

        return files.map(f => analyze(fs.readFileSync(dir+"/"+f,"utf-8")))
      }
    }
  ]
}
