
const express = require("express")
const { auditQueue } = require("../../packages/queue")

const app = express()
app.use(express.json())

app.post("/v1/audit", async (req,res)=>{
  const job = await auditQueue.add("audit", req.body)
  res.json({ jobId: job.id })
})

app.listen(3001,()=>console.log("API running"))
