
import { Worker } from "bullmq"
import { runAudit } from "../mcp-host/host"

new Worker("audit", async job => {
  return await runAudit(job.data)
}, {
  connection: { host: "localhost", port: 6379 }
})
