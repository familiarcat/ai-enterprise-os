
create table customers (
  id uuid primary key default gen_random_uuid(),
  email text,
  created_at timestamp default now()
);

create table revenue (
  id uuid primary key default gen_random_uuid(),
  project_id uuid,
  customer_id uuid,
  amount float,
  created_at timestamp default now()
);
