
function generateLandingPage(product){
  return {
    title: product,
    description: "Automated AI solution for " + product,
    pricing: "$29/month"
  }
}

module.exports = { generateLandingPage }
