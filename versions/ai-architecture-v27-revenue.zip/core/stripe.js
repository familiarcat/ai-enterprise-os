
const Stripe = require("stripe")
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY)

async function createCheckout(amount){
  return await stripe.checkout.sessions.create({
    payment_method_types: ["card"],
    line_items: [{
      price_data: {
        currency: "usd",
        product_data: { name: "AI Service" },
        unit_amount: amount * 100
      },
      quantity: 1
    }],
    mode: "payment",
    success_url: "http://localhost:3000/success",
    cancel_url: "http://localhost:3000/cancel"
  })
}

module.exports = { createCheckout }
