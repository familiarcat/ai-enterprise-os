
const express = require("express")
const { createCheckout } = require("../../core/stripe")
const { supabase } = require("../../core/supabase")
const { generateLandingPage } = require("../../domains/marketing/generator")

const app = express()
app.use(express.json())

app.post("/create-product", async (req,res)=>{
  const { name } = req.body
  const page = generateLandingPage(name)
  res.json(page)
})

app.post("/checkout", async (req,res)=>{
  const session = await createCheckout(req.body.amount)
  res.json({ url: session.url })
})

app.post("/record-revenue", async (req,res)=>{
  await supabase.from("revenue").insert(req.body)
  res.json({ status: "recorded" })
})

app.listen(process.env.API_PORT || 3001)
