
# v27 Revenue Engine (Customer + Monetization Layer)

Features:
- Customer acquisition pipeline
- Landing page generator scaffold
- Revenue tracking (Supabase)
- Stripe integration scaffold
- Marketing + Sales MCP hooks
- Extends v26 Fund System into real revenue loop

Run:
cp .env.example .env
npm install
npm run dev
