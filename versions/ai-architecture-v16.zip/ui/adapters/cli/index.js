
const axios=require('axios')
async function run(){
 const r=await axios.post('http://localhost:3001/v1/run')
 console.log(r.data)
}
run()
