
const vscode = require('vscode')
const axios = require('axios')

function activate(context){
 let disposable = vscode.commands.registerCommand('ai.runCycle', async function(){
   const res = await axios.post('http://localhost:3001/v1/run')
   vscode.window.showInformationMessage(JSON.stringify(res.data))
 })
 context.subscriptions.push(disposable)
}

function deactivate(){}

module.exports = { activate, deactivate }
