
export default function DebateViewer({responses}){
 return <div>{responses?.map((r,i)=><div key={i}>{r.agent}:{r.text}</div>)}</div>
}
