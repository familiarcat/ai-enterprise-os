
export async function runCycle(context){
  return {
    mission: context || "optimize system",
    responses: [
      {agent:"data",text:"plan",confidence:0.9},
      {agent:"geordi",text:"analysis",confidence:0.8}
    ],
    decision: {agent:"worf",text:"approved"}
  }
}
