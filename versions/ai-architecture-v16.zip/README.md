
# v16 Universal AI Runtime

Core + Runtime abstraction + UI adapters (web, vscode, cli)

Run (local):
npm install
npm run dev

VSCode extension:
cd ui/adapters/vscode
npm install
npm run build
