
import { runCycle } from "../../core/orchestrator"

export async function runLocal(context){
  return runCycle(context)
}
