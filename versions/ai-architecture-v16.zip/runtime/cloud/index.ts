
export async function runCloud(context){
  // placeholder for API-based execution
  return fetch("/api/run", {method:"POST"})
}
