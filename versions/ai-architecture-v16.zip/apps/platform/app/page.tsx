
'use client'
import {useState} from 'react'
export default function Home(){
 const [d,setD]=useState(null)
 async function run(){
  const r=await fetch("http://localhost:3001/v1/run",{method:"POST"})
  setD(await r.json())
 }
 return <div>
  <h1>v16 Web UI</h1>
  <button onClick={run}>Run</button>
  <pre>{JSON.stringify(d,null,2)}</pre>
 </div>
}
