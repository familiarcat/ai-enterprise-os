
const express=require("express")
const { runCycle } = require("../../core/orchestrator")
const app=express()
app.use(express.json())
app.post("/v1/run", async(req,res)=>res.json(await runCycle(req.body)))
app.listen(3001)
