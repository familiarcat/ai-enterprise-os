
# AI Architecture Auditor v7 (Multi-Project SaaS)

Features:
- Supabase-ready schema (projects, audits, usage, ROI)
- Next.js platform (projects + ROI dashboard)
- API with project-scoped audit + marketing
- Basic ROI calculation

Run:
npm install
npm run dev:api
npm run dev:web
