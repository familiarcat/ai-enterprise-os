
const express = require("express")
const app = express()
app.use(express.json())

// In-memory store (replace with Supabase)
const db = {
  projects: [],
  audits: [],
  usage: []
}

function calculateROI(projectId){
  const audits = db.audits.filter(a => a.projectId === projectId)
  const cost = audits.reduce((s,a)=>s+(a.cost||0),0)
  const revenue = audits.reduce((s,a)=>s+(a.revenue||0),0)
  return cost === 0 ? 0 : (revenue - cost) / cost
}

app.post("/v1/projects", (req,res)=>{
  const p = { id: Date.now().toString(), ...req.body }
  db.projects.push(p)
  res.json(p)
})

app.get("/v1/projects", (req,res)=>{
  res.json(db.projects.map(p=>({
    ...p,
    roi: calculateROI(p.id)
  })))
})

app.post("/v1/audit", (req,res)=>{
  const { projectId, repoUrl } = req.body

  const audit = {
    id: Date.now().toString(),
    projectId,
    repoUrl,
    score: 8.1,
    risk: "medium",
    issues: ["Refactor modules"],
    recommendations: ["Improve structure"],
    cost: 0.05,
    revenue: 10
  }

  db.audits.push(audit)

  res.json(audit)
})

app.post("/v1/marketing", (req,res)=>{
  const audit = req.body

  res.json({
    landing: `Improve system (score ${audit.score})`,
    email: `Risk: ${audit.risk}`,
    pricing: "$29/month"
  })
})

app.listen(3001,()=>console.log("API running"))
