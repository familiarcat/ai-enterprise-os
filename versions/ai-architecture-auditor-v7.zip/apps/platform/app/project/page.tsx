
'use client'
import { useState } from 'react'

export default function Project(){
  const [audit,setAudit]=useState(null)
  const projectId = "demo"

  async function runAudit(){
    const res = await fetch("http://localhost:3001/v1/audit",{
      method:"POST",
      headers:{ "Content-Type":"application/json" },
      body: JSON.stringify({ projectId, repoUrl:"test" })
    })
    setAudit(await res.json())
  }

  return (
    <div style={{padding:40}}>
      <h1>Project</h1>
      <button onClick={runAudit}>Run Audit</button>

      {audit && <pre>{JSON.stringify(audit,null,2)}</pre>}
    </div>
  )
}
