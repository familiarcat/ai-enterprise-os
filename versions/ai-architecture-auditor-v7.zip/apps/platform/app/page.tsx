
'use client'
import { useEffect, useState } from 'react'

export default function Home(){
  const [projects,setProjects]=useState([])
  const [name,setName]=useState("")

  async function load(){
    const res = await fetch("http://localhost:3001/v1/projects")
    setProjects(await res.json())
  }

  async function create(){
    await fetch("http://localhost:3001/v1/projects",{
      method:"POST",
      headers:{ "Content-Type":"application/json" },
      body: JSON.stringify({ name })
    })
    setName("")
    load()
  }

  useEffect(()=>{ load() },[])

  return (
    <div style={{padding:40}}>
      <h1>AI SaaS Platform v7</h1>

      <input value={name} onChange={e=>setName(e.target.value)} placeholder="Project name"/>
      <button onClick={create}>Create Project</button>

      <h2>Projects</h2>
      <ul>
        {projects.map(p=>(
          <li key={p.id}>
            {p.name} | ROI: {p.roi}
          </li>
        ))}
      </ul>
    </div>
  )
}
