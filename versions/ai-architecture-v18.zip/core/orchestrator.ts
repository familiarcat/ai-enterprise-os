
import { withRetry } from "./retry"
import { retrieveContext } from "./rag"
import { callTool } from "./tools"

export async function runMission(projectId, input){
  const memory = await retrieveContext(input)

  const execution = await withRetry(async ()=>{
    const toolResult = await callTool("analyze_repo", input)
    return {
      responses:[
        {agent:"data",decision:"plan",confidence:0.9},
        {agent:"worf",decision:"approve",confidence:0.95}
      ],
      toolResult,
      memory
    }
  })

  return execution
}
