
export function requireApproval(decision){
  return {
    approved: false,
    message: "Awaiting human approval",
    decision
  }
}
