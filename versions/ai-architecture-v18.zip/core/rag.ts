
export async function retrieveContext(query){
  return ["relevant memory for: " + query]
}
