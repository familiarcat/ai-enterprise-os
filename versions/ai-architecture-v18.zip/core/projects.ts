
let projects = []

export function createProject(name){
  const p = { id: Date.now(), name, missions:[], roi:0 }
  projects.push(p)
  return p
}

export function addMission(projectId, mission){
  const p = projects.find(p=>p.id===projectId)
  p.missions.push(mission)
  return p
}
