
export async function withRetry(fn, retries=2){
  let lastError
  for(let i=0;i<=retries;i++){
    try{
      return await fn()
    }catch(e){
      lastError = e
    }
  }
  throw lastError
}
