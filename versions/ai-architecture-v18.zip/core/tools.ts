
export async function callTool(name, input){
  return { tool:name, result:"real data placeholder", input }
}
