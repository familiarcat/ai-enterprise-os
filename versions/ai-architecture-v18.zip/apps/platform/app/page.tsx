
'use client'
import {useState} from 'react'

export default function Home(){
 const [d,setD]=useState(null)

 async function run(){
  const r=await fetch("http://localhost:3001/mission",{method:"POST",body:JSON.stringify({input:"analyze project"}),headers:{'Content-Type':'application/json'}})
  setD(await r.json())
 }

 return <div>
  <h1>v18 Autonomous AI Company</h1>
  <button onClick={run}>Run Mission</button>
  <pre>{JSON.stringify(d,null,2)}</pre>
 </div>
}
