
const express=require("express")
const { runMission } = require("../../core/orchestrator")

const app=express()
app.use(express.json())

app.post("/mission", async(req,res)=>{
  const result = await runMission(1, req.body.input)
  res.json(result)
})

app.listen(3001)
