
# v18 Autonomous AI Company (Self-Correcting + HITL)

Features:
- Retry + self-healing loops
- MCP-first tool execution
- RAG hooks (memory retrieval)
- Project + mission lifecycle
- Human-in-the-loop checkpoints
