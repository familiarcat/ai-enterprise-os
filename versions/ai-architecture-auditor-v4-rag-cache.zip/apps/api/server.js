const express = require("express")
const app = express()
app.use(express.json())

app.post("/v1/audit", async (req,res)=>{
  res.json({ summary:"RAG+Cache system active", score:9.2 })
})

app.listen(3001,()=>console.log("API running"))
