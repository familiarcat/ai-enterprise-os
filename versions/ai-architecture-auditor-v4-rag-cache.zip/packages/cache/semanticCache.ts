import { supabase } from "../db/supabase"
import { generateEmbedding } from "../ai/embeddings"

export async function checkCache(query){
  const embedding = await generateEmbedding(query)

  const { data } = await supabase.rpc("match_embeddings", {
    query_embedding: embedding,
    match_threshold: 0.92,
    match_count: 1
  })

  return data?.[0] || null
}

export async function storeCache(query, response){
  return supabase.from("embeddings").insert({
    content: JSON.stringify({query, response}),
    metadata: { type: "cache" }
  })
}
