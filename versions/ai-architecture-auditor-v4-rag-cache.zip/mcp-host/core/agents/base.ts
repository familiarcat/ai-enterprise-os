import { openRouterChat } from "../../../packages/openrouter-client"
import { checkCache, storeCache } from "../../../packages/cache/semanticCache"

export class BaseAgent {
  constructor(role, prompt){
    this.role = role
    this.prompt = prompt
  }

  async run(input){
    const key = JSON.stringify(input).slice(0,500)

    const cached = await checkCache(key)
    if(cached){
      console.log("⚡ cache hit")
      return JSON.parse(cached.content).response
    }

    const res = await openRouterChat({
      model: "openai/gpt-4.1-mini",
      messages:[
        {role:"system", content:this.prompt},
        {role:"user", content:key}
      ]
    })

    await storeCache(key, res.content)

    return res.content
  }
}
