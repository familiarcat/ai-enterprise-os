# SOVEREIGN FACTORY: IMPLEMENTATION ROADMAP
## Complete Execution Plan for MCP-Agent System

**Date:** 2026-04-18  
**Status:** Ready for Development  
**Crew Lead:** Picard (orchestration), Data (implementation)

---

## 📊 WHAT YOU'RE BUILDING

A **self-evolving, agent-driven MCP platform** where:

1. **Agents discover** what tools they need
2. **Worf validates** security before integration
3. **Domains auto-expand** to accommodate MCPs
4. **History guides** future decisions
5. **Platform learns** from architectural patterns

---

## 🎯 CORE COMPONENTS (PROVIDED CODE)

### **1. Worf Security Gate** (`worf-security-gate.ts`)
- Evaluates MCPs on 5 criteria (credentials, blast radius, provenance, licensing, audit)
- Calculates security score (0-100)
- Auto-approves (score ≥80), conditionally approves (65-79), rejects (<65)
- Logs decisions to DECISIONS.md
- Updates MCP Manifest

**Key Functions:**
```typescript
evaluateMCP(request)         // Full security evaluation
calculateSecurityScore()     // Weighted scoring
applyWorfDecisionLogic()    // Decision matrix
updateManifest()            // Record approval
```

### **2. Crew Personas** (`crew-personas.ts`)
- 9 Star Trek identities mapped to functional roles
- MCP access matrix (full, read-only, forbidden)
- Domain ownership (primary, secondary)
- System prompts for Claude agents
- Decision authority assignments

**Crew Members:**
- **Picard** — Orchestrator (strategic)
- **Worf** — Security gate (approval authority)
- **Data** — Code analysis & architecture
- **La Forge** — Infrastructure & systems
- **Crusher** — Health & diagnostics
- **Riker** — Operations & coordination
- **Tasha** — Incident response
- **Wesley** — Innovation & experimentation
- **Uhura** — Communications & integration
- **Guinan** — Memory & pattern learning

**Key Functions:**
```typescript
getCrewMCPAccess()           // What MCPs can crew use?
canCrewAccessMCP()          // Access control check
getCrewDomains()            // Crew's domain ownership
findCrewAuthority()         // Who can decide what?
```

### **3. Domain Router** (`domain-router.ts`)
- Routes MCP requests through domain system
- Enforces access control (crew → domain → MCP)
- Auto-expands domains when needed
- Creates DDD layer structure (Domain, Application, Infrastructure)
- Validates rate limits

**Key Functions:**
```typescript
routeRequest()              // Route MCP request with validation
expandDomain()              // Create new domain with DDD layers
validateAccess()            // Check all permissions
listDomains()              // Show all domains
getDomain()                // Get domain details
```

### **4. MCP Manifest** (`mcp-manifest.json`)
- Dynamic catalog of approved/pending/rejected MCPs
- Security review details for each MCP
- Domain assignments
- Crew access permissions
- Rate limits and capabilities

---

## 🚀 IMPLEMENTATION PHASES

### **PHASE 1: Foundation (Week 1)**

**Objective:** Set up core infrastructure

#### Step 1a: Create Project Structure
```bash
mkdir -p core/security
mkdir -p core/crew
mkdir -p core/routing
mkdir -p domains
mkdir -p versions/v14-github-release
mkdir -p tools
mkdir -p .metadata
```

#### Step 1b: Implement Worf Security Gate
- [ ] Copy `worf-security-gate.ts` to `core/security/`
- [ ] Create `types.ts` with interfaces (MCPRequest, ApprovalDecision, etc.)
- [ ] Implement security evaluation logic
- [ ] Write unit tests (Jest)
- [ ] Test with example MCPs

**Test Case:**
```typescript
// Test Stripe MCP evaluation
const stripeRequest = {
  id: 'stripe-mcp',
  name: 'Stripe Payments',
  security_info: {
    hardcoded_secrets: false,
    encryption_transit: true,
    blast_radius: 'high',
    github_stars: 450,
    license: 'MIT',
  },
};

const decision = await worf.evaluateMCP(stripeRequest);
expect(decision.status).toBe('approved_with_restrictions');
expect(decision.security_score).toBeGreaterThan(65);
```

#### Step 1c: Initialize MCP Manifest
- [ ] Create `mcp-manifest.json` (use provided template)
- [ ] Add 5 starter MCPs (GitHub, PostgreSQL, Claude, AWS Secrets, Datadog)
- [ ] Create approval tracking

#### Step 1d: Create CI/CD Job for Manifest Updates
```yaml
# .github/workflows/mcp-manifest.yml
name: Update MCP Manifest

on:
  schedule:
    - cron: '0 * * * *'  # Hourly
  workflow_dispatch:

jobs:
  sync:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - name: Query gitmcp.io
        run: node tools/sync-mcp-catalog.js
      - name: Validate manifest
        run: node tools/validate-manifest.js
      - name: Commit if changed
        run: |
          git add mcp-manifest.json
          git diff --quiet && git commit -m "chore: update MCP manifest"
```

---

### **PHASE 2: Crew System (Week 2)**

**Objective:** Implement agent personas and decision authority

#### Step 2a: Implement Crew Personas
- [ ] Copy `crew-personas.ts` to `core/crew/`
- [ ] Define all 9 crew members with:
  - System prompts for Claude
  - MCP access matrix
  - Domain ownership
  - Decision authority

#### Step 2b: Create Agent Context System
```typescript
// core/crew/agent-context.ts
export class AgentContext {
  constructor(crewId: string) {
    const persona = CREW_PERSONAS[crewId];
    this.systemPrompt = persona.system_prompt;
    this.mcp_access = getCrewMCPAccess(crewId);
    this.domains = getCrewDomains(crewId);
  }

  // Used when calling Claude
  getSystemPrompt(): string {
    return this.systemPrompt;
  }

  // Used for access control
  canAccessMCP(mcp_id: string): boolean {
    return canCrewAccessMCP(this.crewId, mcp_id);
  }
}
```

#### Step 2c: Create Claude Integration
```typescript
// core/crew/claude-integration.ts
export class ClaudeAgent {
  async execute(crewId: string, prompt: string, mcp_tool: string) {
    const context = new AgentContext(crewId);
    
    const response = await claude.messages.create({
      model: 'claude-opus-4-6',
      max_tokens: 2000,
      system: context.getSystemPrompt(),
      tools: [
        {
          name: mcp_tool,
          description: `MCP: ${mcp_tool}`,
          input_schema: { /* ... */ }
        }
      ],
      messages: [{ role: 'user', content: prompt }]
    });

    // Validate MCP access before execution
    if (!context.canAccessMCP(mcp_tool)) {
      throw new Error(`${crewId} not authorized for ${mcp_tool}`);
    }

    return response;
  }
}
```

#### Step 2d: Write Tests for Crew System
```typescript
// tests/crew.test.ts
describe('Crew Personas', () => {
  test('Worf can access security MCPs', () => {
    expect(canCrewAccessMCP('worf', 'aws-secrets-manager-mcp')).toBe(true);
  });

  test('Data cannot access security MCPs', () => {
    expect(canCrewAccessMCP('data', 'aws-secrets-manager-mcp')).toBe(false);
  });

  test('Picard owns core domain', () => {
    const domains = getCrewDomains('picard');
    expect(domains.primary).toContain('core');
  });
});
```

---

### **PHASE 3: Domain Router (Week 3)**

**Objective:** Implement MCP routing and domain auto-expansion

#### Step 3a: Implement Domain Router
- [ ] Copy `domain-router.ts` to `core/routing/`
- [ ] Implement `routeRequest()` with full access validation
- [ ] Implement `expandDomain()` with DDD layer creation

#### Step 3b: Create Domain Structure Template
```typescript
// domains/[domain-name]/
// ├── mcp.json                          (domain config)
// ├── README.md
// ├── domain/                           (Domain layer)
// │   ├── entities.ts
// │   ├── value-objects.ts
// │   └── aggregates.ts
// ├── application/                      (Application layer)
// │   ├── services.ts
// │   ├── dto.ts
// │   └── use-cases.ts
// └── infrastructure/                   (Infrastructure layer)
//     ├── persistence.ts
//     ├── mcp-gateway.ts
//     └── external-services.ts
```

#### Step 3c: Implement Auto-Domain Creation
```typescript
// Example: Agent needs payments domain
const router = new DomainRouter('domains', 'mcp-manifest.json');

await router.expandDomain({
  domain_name: 'payments',
  owner_crew_id: 'data',
  reason: 'Stripe integration for payment processing',
  mcp_id: 'stripe-mcp',
  worf_approved: true
});

// Creates:
// domains/payments/
// ├── mcp.json
// ├── domain/
// ├── application/
// └── infrastructure/
```

#### Step 3d: Create MCP Gateway Pattern
```typescript
// domains/payments/infrastructure/mcp-gateway.ts
export class StripeGateway {
  constructor(private mcpClient: MCPClient) {}

  async createPayment(params: PaymentParams): Promise<PaymentResult> {
    // Route through domain router
    return await this.mcpClient.execute({
      crew_id: 'data',
      domain: 'payments',
      mcp_id: 'stripe-mcp',
      action: 'create_payment',
      params
    });
  }

  async refundPayment(paymentId: string): Promise<RefundResult> {
    return await this.mcpClient.execute({
      crew_id: 'data',
      domain: 'payments',
      mcp_id: 'stripe-mcp',
      action: 'refund_payment',
      params: { payment_id: paymentId }
    });
  }
}
```

#### Step 3e: Test Domain Routing
```typescript
// tests/domain-router.test.ts
describe('Domain Router', () => {
  test('routes request through domain', async () => {
    const router = new DomainRouter('domains', 'mcp-manifest.json');
    
    const result = await router.routeRequest({
      crew_id: 'data',
      domain: 'payments',
      mcp_id: 'stripe-mcp',
      action: 'create_payment',
      params: { amount: 1000 }
    });

    expect(result.status).toBe('success');
  });

  test('blocks unauthorized access', async () => {
    const router = new DomainRouter('domains', 'mcp-manifest.json');
    
    await expect(
      router.routeRequest({
        crew_id: 'crusher',  // Not authorized for payments
        domain: 'payments',
        mcp_id: 'stripe-mcp',
        action: 'create_payment',
        params: { amount: 1000 }
      })
    ).rejects.toThrow();
  });

  test('auto-expands domain when needed', async () => {
    const router = new DomainRouter('domains', 'mcp-manifest.json');
    
    const domain = await router.expandDomain({
      domain_name: 'notifications',
      owner_crew_id: 'uhura',
      reason: 'SMS/email notifications',
      mcp_id: 'twilio-mcp',
      worf_approved: false  // Pending review
    });

    expect(domain.name).toBe('notifications');
    expect(domain.mcp_integrations[0].status).toBe('testing');
  });
});
```

---

### **PHASE 4: Version Management & Learning (Week 4)**

**Objective:** Implement historical learning system

#### Step 4a: Version Snapshot System
```typescript
// tools/version-manager.ts
export class VersionManager {
  async createSnapshot() {
    // 1. Zip current codebase
    const zipPath = `versions/v${VERSION}/ai-architecture-v${VERSION}.zip`;
    await zipProject(zipPath);

    // 2. Extract patterns from codebase
    const patterns = await this.analyzePatterns();
    fs.writeFileSync(
      `versions/v${VERSION}/patterns.json`,
      JSON.stringify(patterns, null, 2)
    );

    // 3. Copy current decisions
    fs.copyFileSync(
      'DECISIONS.md',
      `versions/v${VERSION}/DECISIONS.md`
    );

    // 4. Prune old versions (keep last 5)
    await this.pruneOldVersions(5);
  }

  async pruneOldVersions(keep: number) {
    const versions = fs.readdirSync('versions')
      .filter(v => /^v\d+/.test(v))
      .sort((a, b) => parseInt(b.replace(/v/, '')) - parseInt(a.replace(/v/, '')));

    for (const version of versions.slice(keep)) {
      const archivePath = `versions_archive/${version}.tar.gz`;
      await tar.create({ file: archivePath, cwd: 'versions' }, [version]);
      fs.rmSync(`versions/${version}`, { recursive: true });
    }
  }
}
```

#### Step 4b: Pattern Learning System
```typescript
// tools/pattern-learner.ts
export class PatternLearner {
  async learnFromHistory() {
    const versions = this.getVersions();
    
    for (const version of versions) {
      // Read patterns from version
      const patterns = JSON.parse(
        fs.readFileSync(`versions/${version}/patterns.json`, 'utf-8')
      );

      // Extract decisions
      const decisions = this.parseDecisions(
        fs.readFileSync(`versions/${version}/DECISIONS.md`, 'utf-8')
      );

      // Update agent memory
      await this.updateAgentMemory(version, patterns, decisions);
    }

    // Generate summary for Guinan (counselor)
    const summary = this.generateHistoricalSummary();
    return summary;
  }

  generateHistoricalSummary(): HistoricalContext {
    return {
      version_count: this.getVersionCount(),
      mcp_patterns: this.extractMCPPatterns(),
      domain_patterns: this.extractDomainPatterns(),
      decision_trends: this.analyzeTrends(),
      learned_lessons: this.extractLessons(),
    };
  }
}
```

#### Step 4c: Create DECISIONS.md Schema
```markdown
# Architectural Decisions

## [Version 14] Stripe MCP Integration - 2026-04-18

### Decision
Add Stripe Payments MCP to payments domain

### Context
- Feature request: Process payment transactions
- Alternative: Build in-house payment gateway
- Cost: ~$500/month in Stripe fees
- Risk: External service dependency

### Decision
Integrate Stripe via official Stripe MCP

### Consequences
- Pros: Battle-tested, official support, PCI compliance built-in
- Cons: External dependency, transaction fees, learning curve
- Risk: Service outage impacts payment processing

### Alternatives Considered
1. PayPal MCP - more expensive, complex API
2. Square MCP - good alternative, slightly less feature-rich
3. Build custom gateway - too much dev time, no PCI guarantee

### Decision Maker
Worf (security approval), Data (architecture decision)

### Related Decisions
- v13: Initial payments domain design
- v12: Database schema for transactions
```

#### Step 4d: Guinan Memory System Integration
```typescript
// core/crew/guinan-memory.ts
export class GuinanMemorySystem {
  async queryHistory(question: string): Promise<HistoricalContext> {
    // Query version history
    const versions = await this.getVersions();

    // Use Claude to analyze patterns
    const analysis = await claude.messages.create({
      model: 'claude-opus-4-6',
      system: CREW_PERSONAS.guinan.system_prompt,
      messages: [{
        role: 'user',
        content: `Looking at our architecture history (versions ${versions.join(', ')}), ${question}`
      }]
    });

    return this.parseAnalysis(analysis);
  }

  async synthesizeMemories(): Promise<AgentMemories> {
    // Each crew member has memory of past decisions relevant to their role
    const memories: AgentMemories = {};

    for (const [crewId, persona] of Object.entries(CREW_PERSONAS)) {
      memories[crewId] = await this.buildCrewMemory(crewId, persona);
    }

    return memories;
  }

  private async buildCrewMemory(crewId: string, persona: CrewPersona): Promise<CrewMemory> {
    return {
      crew_id: crewId,
      past_decisions: await this.getPastDecisionsForCrew(crewId),
      learned_patterns: await this.getPatternsForCrew(crewId),
      success_cases: await this.getSuccessCases(crewId),
      failure_cases: await this.getFailureCases(crewId),
    };
  }
}
```

---

### **PHASE 5: Claude Integration (Week 5)**

**Objective:** Full Claude-native MCP access

#### Step 5a: Create MCP Server for Claude
```typescript
// apps/api/claude-mcp-server.ts
import Anthropic from '@anthropic-sdk/sdk';

export class SovereignFactoryMCP {
  private client = new Anthropic();

  async createServer() {
    return {
      name: 'sovereign-factory',
      version: '1.0.0',
      tools: [
        {
          name: 'analyze_project',
          description: 'Analyze project structure and history',
          input_schema: {
            type: 'object',
            properties: {
              query: { type: 'string' }
            }
          }
        },
        {
          name: 'request_mcp',
          description: 'Request MCP approval from Worf',
          input_schema: {
            type: 'object',
            properties: {
              mcp_id: { type: 'string' },
              reason: { type: 'string' }
            }
          }
        },
        {
          name: 'create_domain',
          description: 'Create new domain for MCP integration',
          input_schema: {
            type: 'object',
            properties: {
              domain_name: { type: 'string' },
              mcp_id: { type: 'string' },
              reason: { type: 'string' }
            }
          }
        },
        {
          name: 'query_patterns',
          description: 'Learn from architectural patterns',
          input_schema: {
            type: 'object',
            properties: {
              question: { type: 'string' }
            }
          }
        }
      ]
    };
  }

  async handleTool(toolName: string, toolInput: any): Promise<any> {
    switch (toolName) {
      case 'analyze_project':
        return await this.analyzeProject(toolInput.query);
      case 'request_mcp':
        return await this.requestMCPApproval(toolInput);
      case 'create_domain':
        return await this.createDomain(toolInput);
      case 'query_patterns':
        return await this.queryPatterns(toolInput.question);
      default:
        throw new Error(`Unknown tool: ${toolName}`);
    }
  }

  private async analyzeProject(query: string): Promise<any> {
    // Query version history and current state
    return await versionManager.queryHistory(query);
  }

  private async requestMCPApproval(input: any): Promise<any> {
    // Delegate to Worf
    const worf = new WorfSecurityGate('mcp-manifest.json');
    return await worf.evaluateMCP({
      id: input.mcp_id,
      name: input.mcp_id,
      requested_by: 'claude-agent',
      reason: input.reason
    });
  }

  private async createDomain(input: any): Promise<any> {
    // Create domain via router
    const router = new DomainRouter('domains', 'mcp-manifest.json');
    return await router.expandDomain({
      domain_name: input.domain_name,
      owner_crew_id: 'data',
      reason: input.reason,
      mcp_id: input.mcp_id,
      worf_approved: false
    });
  }

  private async queryPatterns(question: string): Promise<any> {
    // Query Guinan memory system
    return await guinanMemory.queryHistory(question);
  }
}
```

#### Step 5b: Multi-Agent Orchestration
```typescript
// core/crew/multi-agent-orchestrator.ts
export class MultiAgentOrchestrator {
  async runMission(userRequest: string) {
    console.log(`🖖 PICARD: Mission briefing...`);

    // 1. Picard analyzes request
    const plan = await this.runAgent('picard', `Plan this mission: ${userRequest}`);
    console.log(`Picard's plan: ${plan}`);

    // 2. Worf checks security
    const security = await this.runAgent('worf', `What are security implications?`);
    console.log(`Worf's assessment: ${security}`);

    // 3. Data designs architecture
    const architecture = await this.runAgent('data', `Design the architecture for this`);
    console.log(`Data's design: ${architecture}`);

    // 4. La Forge prepares infrastructure
    const infra = await this.runAgent('la_forge', `What infrastructure is needed?`);
    console.log(`La Forge's plan: ${infra}`);

    // 5. Execute mission
    return {
      plan,
      security_review: security,
      architecture,
      infrastructure: infra,
      status: 'ready_for_execution'
    };
  }

  private async runAgent(crewId: string, prompt: string): Promise<string> {
    const context = new AgentContext(crewId);
    const agent = new ClaudeAgent();

    const response = await agent.execute(crewId, prompt, 'analyze_project');
    return this.parseResponse(response);
  }
}
```

---

## 📋 TESTING STRATEGY

### Unit Tests (Jest)
```bash
npm test -- core/security     # Worf evaluation tests
npm test -- core/crew         # Crew persona tests
npm test -- core/routing      # Domain router tests
npm test -- tools/patterns    # Pattern learning tests
```

### Integration Tests
```bash
npm test:integration          # End-to-end flows
npm test:e2e                  # Full mission scenarios
```

### Test Coverage
```bash
npm test -- --coverage
# Target: 80%+ coverage
# Critical: 100% for security gate
```

---

## 📦 DEPLOYMENT CHECKLIST

- [ ] All tests passing (Jest)
- [ ] Type checking clean (TypeScript)
- [ ] Code coverage ≥80%
- [ ] Linting passes (ESLint)
- [ ] Security audit clean (npm audit)
- [ ] Documentation complete
- [ ] Example missions documented
- [ ] CI/CD pipeline ready

---

## 🎯 SUCCESS CRITERIA

When Phase 5 is complete, you have:

✅ **Agent-Driven MCP Discovery**
- Agents query gitmcp.io
- Request MCPs via Claude

✅ **Security-Gated Integration**
- Worf evaluates every MCP
- Automatic score calculation
- Clear approval/rejection logic

✅ **Auto-Expanding Domains**
- New domains created as needed
- DDD structure enforced
- MCP gateways created automatically

✅ **Intelligent Memory System**
- Version history tracked
- Patterns extracted & learned
- Decisions documented

✅ **Full Claude Integration**
- Multi-agent teams active
- MCP tools available in Claude
- Autonomous mission loops

✅ **Production Ready**
- 80%+ test coverage
- Full documentation
- Audit trails complete
- Rollback capability

---

## 🖖 NEXT IMMEDIATE STEPS

### This Week:
1. **Copy provided code files** to your repo
2. **Implement Phase 1** (Worf security gate)
3. **Write unit tests**
4. **Create MCP manifest**

### Next Week:
1. **Implement Phase 2** (Crew personas)
2. **Create Claude integration context**
3. **Write integration tests**

### Following Weeks:
1. **Implement Phase 3** (Domain router)
2. **Implement Phase 4** (Version system)
3. **Implement Phase 5** (Multi-agent orchestration)

---

## 📞 QUICK REFERENCE

**Key Files Provided:**
- `worf-security-gate.ts` — Security evaluation
- `crew-personas.ts` — Agent definitions
- `domain-router.ts` — MCP routing
- `mcp-manifest.json` — MCP catalog

**Key Concepts:**
- **Worf Decision Matrix** — 40% credentials, 30% blast radius, 15% provenance, 10% licensing, 5% audit
- **Crew Access Model** — Full, read-only, or forbidden per MCP
- **Domain Auto-Expansion** — New domain created when agent requests MCP
- **Version Learning** — Agents query history for patterns

---

**Status:** Ready for implementation  
**Estimated Timeline:** 5 weeks (1 phase/week)  
**Team Required:** 2-3 developers  
**Current Blocker:** None

🖖 **Make it so.**
