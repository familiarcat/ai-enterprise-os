/**
 * WORF SECURITY GATE
 * Purpose: Validate and approve MCPs before integration
 * Crew: Worf (Chief Security Officer)
 * Authority: Final decision on MCP inclusion
 */

import { MCPRequest, SecurityReview, ApprovalDecision } from './types';
import * as fs from 'fs';

export class WorfSecurityGate {
  private manifest: any;
  private securityScores: Map<string, number> = new Map();

  constructor(manifestPath: string) {
    this.manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf-8'));
  }

  /**
   * Evaluate an MCP request
   * Worf's decision matrix:
   * - Credential security (40%)
   * - Blast radius (30%)
   * - Code provenance (15%)
   * - Licensing (10%)
   * - Audit capability (5%)
   */
  async evaluateMCP(request: MCPRequest): Promise<ApprovalDecision> {
    console.log(`\n🛡️  WORF: Evaluating ${request.name}...`);

    const evaluation = {
      credential_security: this.evaluateCredentials(request),
      blast_radius: this.evaluateBlastRadius(request),
      code_provenance: this.evaluateProvenance(request),
      licensing: this.evaluateLicensing(request),
      audit_capability: this.evaluateAudit(request),
    };

    // Calculate security score
    const score = this.calculateSecurityScore(evaluation);
    console.log(`📊 Security Score: ${score}/100`);

    // Apply Worf's decision logic
    const decision = this.applyWorfDecisionLogic(evaluation, score, request);

    // Log decision
    this.logDecision(request, decision, evaluation);

    // Update manifest if approved
    if (decision.status === 'approved') {
      this.updateManifest(request, decision);
    }

    return decision;
  }

  /**
   * Evaluate credential handling (40% weight)
   * ✓ AWS Secrets Manager integration
   * ✓ No hardcoded secrets
   * ✓ Encryption in transit
   */
  private evaluateCredentials(request: MCPRequest): number {
    const checks = {
      hardcoded_secrets: request.security_info?.hardcoded_secrets === false ? 100 : 0,
      encryption_transit: request.security_info?.encryption_transit ? 100 : 50,
      secret_management: this.hasSecretManagement(request) ? 100 : 30,
      key_rotation: request.security_info?.supports_key_rotation ? 100 : 50,
    };

    const score = Object.values(checks).reduce((a, b) => a + b) / Object.keys(checks).length;
    
    if (score < 70) {
      console.log(`  ⚠️  Credential handling: RISKY (${score.toFixed(0)}%)`);
    } else {
      console.log(`  ✓ Credential handling: SECURE (${score.toFixed(0)}%)`);
    }

    return score;
  }

  /**
   * Evaluate blast radius (30% weight)
   * CRITICAL: Full system access → reject unless exceptional
   * HIGH: Data/infrastructure access → require strong controls
   * MEDIUM: Limited access → generally acceptable
   * LOW: Read-only → safe
   */
  private evaluateBlastRadius(request: MCPRequest): number {
    const radius = request.security_info?.blast_radius || 'unknown';

    const radiusMap: Record<string, number> = {
      'critical': 0,      // Auto-reject
      'high': 40,         // Requires exceptional justification
      'medium': 75,       // Generally acceptable
      'low': 100,         // Preferred
      'unknown': 30,      // Risky
    };

    const score = radiusMap[radius] || 30;

    console.log(`  ${radius === 'critical' ? '❌' : '✓'} Blast radius: ${radius.toUpperCase()} (${score}%)`);

    return score;
  }

  /**
   * Evaluate code provenance (15% weight)
   * ✓ Official source (GitHub ModelContextProtocol, AWS, etc.)
   * ✓ Community verified (200+ stars, active maintenance)
   * ⚠️  Unknown or new (<100 stars, <6 months old)
   * ❌ Archived, deprecated, or suspicious
   */
  private evaluateProvenance(request: MCPRequest): number {
    const provenance = request.security_info?.provenance || 'unknown';
    const github_stars = request.security_info?.github_stars || 0;
    const last_updated = request.security_info?.last_updated_days_ago || 999;

    let score = 0;

    if (request.security_info?.is_official) {
      score = 100;
      console.log(`  ✓ Code provenance: OFFICIAL (100%)`);
    } else if (github_stars > 200 && last_updated < 90) {
      score = 85;
      console.log(`  ✓ Code provenance: COMMUNITY VERIFIED (${github_stars} stars, ${last_updated}d old) (85%)`);
    } else if (github_stars > 100 && last_updated < 180) {
      score = 60;
      console.log(`  ⚠️  Code provenance: MODERATE (${github_stars} stars, ${last_updated}d old) (60%)`);
    } else if (github_stars > 50) {
      score = 40;
      console.log(`  ⚠️  Code provenance: UNPROVEN (${github_stars} stars) (40%)`);
    } else {
      score = 10;
      console.log(`  ❌ Code provenance: UNKNOWN or SUSPICIOUS (${score}%)`);
    }

    return score;
  }

  /**
   * Evaluate licensing (10% weight)
   * ✓ MIT, Apache 2.0, BSD, ISC → Compatible
   * ⚠️  GPL → Requires careful consideration
   * ❌ Proprietary/Incompatible → Reject
   */
  private evaluateLicensing(request: MCPRequest): number {
    const license = request.security_info?.license || 'unknown';

    const compatible = ['MIT', 'Apache-2.0', 'BSD', 'ISC', 'Apache'];
    const incompatible = ['GPL', 'AGPL', 'proprietary'];

    let score = 0;

    if (compatible.some(l => license.includes(l))) {
      score = 100;
      console.log(`  ✓ Licensing: COMPATIBLE (${license}) (100%)`);
    } else if (license.includes('GPL')) {
      score = 30;
      console.log(`  ⚠️  Licensing: GPL - requires review (${license}) (30%)`);
    } else if (incompatible.some(l => license.includes(l))) {
      score = 0;
      console.log(`  ❌ Licensing: INCOMPATIBLE (${license}) (0%)`);
    } else {
      score = 50;
      console.log(`  ⚠️  Licensing: UNKNOWN (${license}) (50%)`);
    }

    return score;
  }

  /**
   * Evaluate audit capability (5% weight)
   * ✓ Full request/response logging
   * ✓ CloudTrail / audit service integration
   * ⚠️  Partial logging
   * ❌ No audit trail
   */
  private evaluateAudit(request: MCPRequest): number {
    const has_audit = request.security_info?.audit_capability || false;
    const audit_integration = request.security_info?.audit_integration;

    let score = 0;

    if (has_audit && audit_integration) {
      score = 100;
      console.log(`  ✓ Audit capability: FULL (${audit_integration}) (100%)`);
    } else if (has_audit) {
      score = 80;
      console.log(`  ✓ Audit capability: BASIC (80%)`);
    } else {
      score = 20;
      console.log(`  ❌ Audit capability: NONE (20%)`);
    }

    return score;
  }

  /**
   * Calculate weighted security score
   */
  private calculateSecurityScore(evaluation: any): number {
    const weights = {
      credential_security: 0.40,
      blast_radius: 0.30,
      code_provenance: 0.15,
      licensing: 0.10,
      audit_capability: 0.05,
    };

    let score = 0;
    for (const [key, weight] of Object.entries(weights)) {
      score += evaluation[key] * (weight as number);
    }

    return Math.round(score);
  }

  /**
   * Worf's decision logic
   * Hard rules that override other factors:
   */
  private applyWorfDecisionLogic(
    evaluation: any,
    score: number,
    request: MCPRequest
  ): ApprovalDecision {
    const decision: ApprovalDecision = {
      status: 'pending',
      security_score: score,
      approved_by: 'worf',
      timestamp: new Date().toISOString(),
      reasoning: [],
    };

    // Hard reject rules
    if (evaluation.credential_security < 50) {
      decision.status = 'rejected';
      decision.reasoning.push('Credential handling is UNSAFE. Requires encryption and secrets management.');
      console.log(`\n❌ WORF DECISION: REJECTED`);
      console.log(`   Reason: Inadequate credential security`);
      return decision;
    }

    if (evaluation.blast_radius === 0) {
      decision.status = 'rejected';
      decision.reasoning.push('Blast radius is CRITICAL. Too dangerous to integrate.');
      console.log(`\n❌ WORF DECISION: REJECTED`);
      console.log(`   Reason: Blast radius is critical`);
      return decision;
    }

    if (evaluation.licensing === 0) {
      decision.status = 'rejected';
      decision.reasoning.push('License is incompatible with our platform.');
      console.log(`\n❌ WORF DECISION: REJECTED`);
      console.log(`   Reason: Incompatible license`);
      return decision;
    }

    // Score-based rules
    if (score >= 80) {
      decision.status = 'approved';
      decision.reasoning.push(`Security score ${score}/100 meets approval threshold.`);
      console.log(`\n✅ WORF DECISION: APPROVED`);
      console.log(`   Security Score: ${score}/100`);
    } else if (score >= 65) {
      decision.status = 'approved_with_restrictions';
      decision.reasoning.push(`Security score ${score}/100 requires additional controls.`);
      decision.restrictions = this.defineRestrictions(evaluation);
      console.log(`\n⚠️  WORF DECISION: APPROVED WITH RESTRICTIONS`);
      console.log(`   Security Score: ${score}/100`);
      console.log(`   Restrictions: ${decision.restrictions?.join(', ')}`);
    } else {
      decision.status = 'rejected';
      decision.reasoning.push(`Security score ${score}/100 below minimum threshold (65).`);
      console.log(`\n❌ WORF DECISION: REJECTED`);
      console.log(`   Reason: Insufficient security score (${score}/100, minimum: 65)`);
    }

    return decision;
  }

  /**
   * Define usage restrictions for conditional approvals
   */
  private defineRestrictions(evaluation: any): string[] {
    const restrictions: string[] = [];

    if (evaluation.credential_security < 80) {
      restrictions.push('Requires AWS Secrets Manager');
      restrictions.push('Read-only access only');
    }

    if (evaluation.code_provenance < 70) {
      restrictions.push('Requires 30-day probation period');
      restrictions.push('Limited to internal use only');
    }

    if (evaluation.audit_capability < 80) {
      restrictions.push('Requires enhanced logging');
      restrictions.push('Quarterly security audit');
    }

    return restrictions;
  }

  /**
   * Log decision to DECISIONS.md
   */
  private logDecision(request: MCPRequest, decision: ApprovalDecision, evaluation: any): void {
    const decisionEntry = {
      date: new Date().toISOString(),
      mcp_id: request.id,
      mcp_name: request.name,
      requested_by: request.requested_by,
      decision: decision.status,
      security_score: decision.security_score,
      evaluation: evaluation,
      reasoning: decision.reasoning,
      restrictions: decision.restrictions,
    };

    // Would append to versions/v14/DECISIONS.md in real implementation
    console.log(`\n📝 Decision logged: ${JSON.stringify(decisionEntry, null, 2)}`);
  }

  /**
   * Update mcp-manifest.json with approved MCP
   */
  private updateManifest(request: MCPRequest, decision: ApprovalDecision): void {
    if (decision.status !== 'approved') return;

    // Add to approved_mcps section
    this.manifest.approved_mcps.push({
      id: request.id,
      name: request.name,
      status: 'approved',
      approved_date: new Date().toISOString().split('T')[0],
      approved_by: 'worf',
      security_score: decision.security_score,
      domains: request.domains || [],
      accessible_to: request.accessible_to || [],
      capabilities: request.capabilities || [],
    });

    // Write back to file
    fs.writeFileSync(
      'mcp-manifest.json',
      JSON.stringify(this.manifest, null, 2)
    );

    console.log(`\n📋 MCP Manifest updated: ${request.name} added to approved list`);
  }

  /**
   * Helper: Check if MCP has secret management
   */
  private hasSecretManagement(request: MCPRequest): boolean {
    const info = request.security_info || {};
    return (
      info.uses_aws_secrets || 
      info.uses_vault || 
      info.supports_env_vars
    );
  }
}

// Example usage
export async function example() {
  const worf = new WorfSecurityGate('mcp-manifest.json');

  const stripeRequest: MCPRequest = {
    id: 'stripe-mcp',
    name: 'Stripe Payments MCP',
    version: '1.0.0',
    requested_by: 'data',
    domains: ['payments'],
    accessible_to: ['data', 'la_forge'],
    capabilities: ['create_payment', 'refund_payment'],
    security_info: {
      hardcoded_secrets: false,
      encryption_transit: true,
      supports_key_rotation: true,
      blast_radius: 'high',
      is_official: false,
      github_stars: 450,
      last_updated_days_ago: 15,
      license: 'MIT',
      audit_capability: true,
      audit_integration: 'Stripe audit logs',
      uses_aws_secrets: true,
    },
  };

  const decision = await worf.evaluateMCP(stripeRequest);
  console.log('\n=== FINAL DECISION ===');
  console.log(JSON.stringify(decision, null, 2));
}
