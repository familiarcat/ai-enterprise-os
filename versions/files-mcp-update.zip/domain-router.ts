/**
 * DOMAIN ROUTER
 * Purpose: Route MCP requests to correct domain, enforce access control
 * Manages: Domain ownership, MCP gateway, access validation
 */

import * as fs from 'fs';
import { CREW_PERSONAS, canCrewAccessMCP, getCrewDomains } from './crew-personas';

export interface MCPRequest {
  crew_id: string;
  domain: string;
  mcp_id: string;
  action: string;
  params: Record<string, any>;
}

export interface DomainConfig {
  name: string;
  owner: string; // Crew member ID
  created_date: string;
  created_by: string;
  reason: string;
  status: 'active' | 'deprecated' | 'sandbox';
  mcp_integrations: MCPIntegration[];
  accessible_to: string[]; // Crew member IDs
  layers: {
    domain_layer: string;
    application_layer: string;
    infrastructure_layer: string;
  };
}

export interface MCPIntegration {
  mcp_id: string;
  status: 'active' | 'deprecated' | 'testing';
  secured_by: string; // Worf
  integration_date: string;
  endpoints: string[];
  rate_limits: Record<string, number>;
}

export class DomainRouter {
  private domains: Map<string, DomainConfig> = new Map();
  private manifest: any;

  constructor(domainsPath: string, manifestPath: string) {
    this.loadDomains(domainsPath);
    this.manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf-8'));
  }

  /**
   * Route an MCP request through domain system
   */
  async routeRequest(request: MCPRequest): Promise<any> {
    console.log(`\n🔀 DOMAIN ROUTER: Routing request from ${request.crew_id}`);
    console.log(
      `   Domain: ${request.domain} | MCP: ${request.mcp_id} | Action: ${request.action}`
    );

    // Step 1: Validate crew member exists
    if (!CREW_PERSONAS[request.crew_id]) {
      throw new Error(`Unknown crew member: ${request.crew_id}`);
    }

    // Step 2: Check if domain exists
    const domain = this.domains.get(request.domain);
    if (!domain) {
      throw new Error(`Domain not found: ${request.domain}. Create with expandDomain() first.`);
    }

    // Step 3: Validate access control
    await this.validateAccess(request, domain);

    // Step 4: Find MCP integration in domain
    const integration = domain.mcp_integrations.find((i) => i.mcp_id === request.mcp_id);
    if (!integration) {
      throw new Error(
        `MCP ${request.mcp_id} not integrated in domain ${request.domain}. Escalate to Worf.`
      );
    }

    // Step 5: Validate rate limits
    this.checkRateLimits(integration, request.action);

    // Step 6: Route to actual MCP
    console.log(`✅ AUTHORIZED: Routing to ${request.mcp_id}`);
    return this.executeInMCP(request, integration);
  }

  /**
   * Validate that crew can access this domain/MCP combination
   */
  private async validateAccess(request: MCPRequest, domain: DomainConfig): Promise<void> {
    const crew = CREW_PERSONAS[request.crew_id];

    // Check if crew is allowed in domain
    const crewDomains = getCrewDomains(request.crew_id);
    const hasAccess =
      crewDomains.primary.includes(request.domain) ||
      crewDomains.secondary?.includes(request.domain) ||
      domain.accessible_to.includes(request.crew_id);

    if (!hasAccess) {
      throw new Error(
        `${request.crew_id} does not have access to domain ${request.domain}. ` +
          `Primary: ${crewDomains.primary.join(', ')}, Secondary: ${crewDomains.secondary?.join(', ')}`
      );
    }

    console.log(`✓ Domain access verified: ${request.crew_id} → ${request.domain}`);

    // Check if crew can access this MCP
    if (!canCrewAccessMCP(request.crew_id, request.mcp_id)) {
      throw new Error(
        `${request.crew_id} is not authorized to use ${request.mcp_id}. ` +
          `Assigned MCPs: ${crew.mcp_access.join(', ')}`
      );
    }

    console.log(`✓ MCP access verified: ${request.crew_id} → ${request.mcp_id}`);
  }

  /**
   * Check rate limits for this MCP action
   */
  private checkRateLimits(integration: MCPIntegration, action: string): void {
    const limit = integration.rate_limits[action];

    if (!limit) {
      console.log(`⚠️  No rate limit defined for action: ${action}`);
      return;
    }

    console.log(`✓ Rate limit check: ${action} (limit: ${limit}/min)`);
    // In real implementation, would track actual usage
  }

  /**
   * Execute request in actual MCP
   */
  private async executeInMCP(request: MCPRequest, integration: MCPIntegration): Promise<any> {
    console.log(`🚀 Executing in ${request.mcp_id}: ${request.action}`);

    // In real implementation, would call actual MCP server
    // For now, return mock result
    return {
      status: 'success',
      mcp: request.mcp_id,
      action: request.action,
      timestamp: new Date().toISOString(),
      result: { /* actual MCP result */ },
    };
  }

  /**
   * DOMAIN AUTO-EXPANSION
   * Create new domain when agent needs one
   */
  async expandDomain(args: {
    domain_name: string;
    owner_crew_id: string;
    reason: string;
    mcp_id: string;
    worf_approved?: boolean;
  }): Promise<DomainConfig> {
    console.log(`\n📦 DOMAIN EXPANSION: Creating ${args.domain_name}`);
    console.log(`   Owner: ${args.owner_crew_id}`);
    console.log(`   MCP: ${args.mcp_id}`);
    console.log(`   Reason: ${args.reason}`);

    // Verify owner exists and has primary domain authority
    const owner = CREW_PERSONAS[args.owner_crew_id];
    if (!owner) {
      throw new Error(`Unknown crew: ${args.owner_crew_id}`);
    }

    // Check if MCP is approved
    if (!args.worf_approved) {
      console.log(
        `⚠️  MCP ${args.mcp_id} not yet approved by Worf. Domain marked as PENDING.`
      );
    }

    // Create domain config
    const domain: DomainConfig = {
      name: args.domain_name,
      owner: args.owner_crew_id,
      created_date: new Date().toISOString().split('T')[0],
      created_by: args.owner_crew_id,
      reason: args.reason,
      status: 'active',
      mcp_integrations: [
        {
          mcp_id: args.mcp_id,
          status: args.worf_approved ? 'active' : 'testing',
          secured_by: 'worf',
          integration_date: new Date().toISOString().split('T')[0],
          endpoints: [], // Populated from MCP manifest
          rate_limits: this.getDefaultRateLimits(args.mcp_id),
        },
      ],
      accessible_to: [args.owner_crew_id],
      layers: {
        domain_layer: `domains/${args.domain_name}/domain/`,
        application_layer: `domains/${args.domain_name}/application/`,
        infrastructure_layer: `domains/${args.domain_name}/infrastructure/`,
      },
    };

    // Store domain
    this.domains.set(args.domain_name, domain);

    // Save to disk
    this.saveDomain(domain);

    // Create directory structure
    this.createDomainStructure(domain);

    console.log(`✅ Domain created: ${args.domain_name}`);
    console.log(`   Layers:`);
    console.log(`   - Domain: ${domain.layers.domain_layer}`);
    console.log(`   - Application: ${domain.layers.application_layer}`);
    console.log(`   - Infrastructure: ${domain.layers.infrastructure_layer}`);

    return domain;
  }

  /**
   * Get default rate limits from manifest
   */
  private getDefaultRateLimits(mcpId: string): Record<string, number> {
    const mcp = this.manifest.approved_mcps?.find((m: any) => m.id === mcpId);
    if (mcp?.rate_limits) {
      return mcp.rate_limits;
    }

    // Fallback defaults
    return {
      read: 1000,
      write: 100,
      delete: 10,
      admin: 1,
    };
  }

  /**
   * Save domain config to disk
   */
  private saveDomain(domain: DomainConfig): void {
    const configPath = `domains/${domain.name}/mcp.json`;

    // Ensure directory exists
    const dir = configPath.split('/').slice(0, -1).join('/');
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }

    // Write config
    fs.writeFileSync(configPath, JSON.stringify(domain, null, 2));
    console.log(`📝 Domain config saved: ${configPath}`);
  }

  /**
   * Create DDD layer structure for domain
   */
  private createDomainStructure(domain: DomainConfig): void {
    const basePath = `domains/${domain.name}`;

    // Create DDD layers
    for (const [key, path] of Object.entries(domain.layers)) {
      const fullPath = `${basePath}/${path}`;
      if (!fs.existsSync(fullPath)) {
        fs.mkdirSync(fullPath, { recursive: true });
        fs.writeFileSync(`${fullPath}/.gitkeep`, '');
      }
    }

    // Create README
    const readme = `# ${domain.name} Domain

## Overview
Created: ${domain.created_date}
Owner: ${domain.owner}
Reason: ${domain.reason}

## MCPs
${domain.mcp_integrations.map((i) => `- ${i.mcp_id}`).join('\n')}

## Access
Accessible to: ${domain.accessible_to.join(', ')}

## Layers
- **Domain Layer**: ${domain.layers.domain_layer}
- **Application Layer**: ${domain.layers.application_layer}
- **Infrastructure Layer**: ${domain.layers.infrastructure_layer}
`;

    fs.writeFileSync(`${basePath}/README.md`, readme);
    console.log(`📝 README created: ${basePath}/README.md`);
  }

  /**
   * Load all domains from disk
   */
  private loadDomains(domainsPath: string): void {
    if (!fs.existsSync(domainsPath)) {
      return;
    }

    const dirs = fs.readdirSync(domainsPath);
    for (const dir of dirs) {
      const configPath = `${domainsPath}/${dir}/mcp.json`;
      if (fs.existsSync(configPath)) {
        const config = JSON.parse(fs.readFileSync(configPath, 'utf-8'));
        this.domains.set(dir, config);
      }
    }

    console.log(`Loaded ${this.domains.size} domains`);
  }

  /**
   * List all domains
   */
  listDomains(): Array<{ name: string; owner: string; status: string }> {
    return Array.from(this.domains.values()).map((d) => ({
      name: d.name,
      owner: d.owner,
      status: d.status,
    }));
  }

  /**
   * Get domain details
   */
  getDomain(name: string): DomainConfig | undefined {
    return this.domains.get(name);
  }
}

// Example usage
export async function example() {
  const router = new DomainRouter('domains', 'mcp-manifest.json');

  // List existing domains
  console.log('\n📋 Existing Domains:');
  router.listDomains().forEach((d) => {
    console.log(`  ${d.name} (owner: ${d.owner}, status: ${d.status})`);
  });

  // Expand domain for new MCP
  console.log('\n🚀 Creating new payments domain...');
  const newDomain = await router.expandDomain({
    domain_name: 'payments',
    owner_crew_id: 'data',
    reason: 'Stripe payment processing required',
    mcp_id: 'stripe-mcp',
    worf_approved: true,
  });

  console.log('\n✅ Domain expansion complete');

  // Route a request
  console.log('\n🔀 Routing request...');
  const result = await router.routeRequest({
    crew_id: 'data',
    domain: 'payments',
    mcp_id: 'stripe-mcp',
    action: 'create_payment',
    params: { amount: 10000, currency: 'USD' },
  });

  console.log('Result:', result);
}
