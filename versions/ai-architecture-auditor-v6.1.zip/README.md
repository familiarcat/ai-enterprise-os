
# AI Architecture Auditor v6.1

Integrated:
- Next.js platform UI
- v5-style governed pipeline (simplified)
- MCP-style audit execution
- Marketing generation

Run:
npm install
npm run dev:api
npm run dev:web
