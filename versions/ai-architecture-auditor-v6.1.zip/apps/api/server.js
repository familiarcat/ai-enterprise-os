
const express = require("express")
const app = express()
app.use(express.json())

async function runPipeline(input){
  const plan = "Generated plan"
  const analysis = "Analyzed repo with MCP tools"
  const validation = "approved"

  if(validation !== "approved"){
    throw new Error("Validation failed")
  }

  const critique = "Score: 8.2"
  const cost = "Optimized"
  const final = {
    score: 8.2,
    risk: "medium",
    issues: ["Modularization needed"],
    recommendations: ["Refactor services"]
  }

  return {
    plan,
    analysis,
    critique,
    cost,
    final
  }
}

app.post("/v1/audit", async (req,res)=>{
  try{
    const result = await runPipeline(req.body)
    res.json(result.final)
  }catch(e){
    res.status(500).json({error:e.message})
  }
})

app.post("/v1/marketing", async (req,res)=>{
  const audit = req.body

  res.json({
    landingPage: `Improve your architecture. Score: ${audit.score}`,
    linkedin: `We analyzed a repo and found ${audit.issues?.length} issues.`,
    email: `Your system risk is ${audit.risk}. Let's fix it.`,
    pricing: "$29/month"
  })
})

app.listen(3001,()=>console.log("API running"))
