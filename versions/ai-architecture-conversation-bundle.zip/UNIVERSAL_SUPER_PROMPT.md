
Use this prompt in any LLM to regenerate the system:

You are an expert AI systems architect.

Build a production-ready AI SaaS platform with:
- MCP multi-agent system
- RAG + semantic cache
- Supabase persistence
- OpenRouter LLM routing
- Distributed MCP mesh
- ROI tracking
- Agile sprint orchestration

Output full repo.
