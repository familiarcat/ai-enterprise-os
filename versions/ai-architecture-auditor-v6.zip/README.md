
# AI Architecture Auditor v6

Full platform:
- Next.js platform UI
- Backend API
- MCP + agents
- Governance + agents.md
- Marketing generator

Run:
npm install
npm run dev:api
npm run dev:web
