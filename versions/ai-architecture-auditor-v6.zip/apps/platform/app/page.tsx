
'use client'
import { useState } from 'react'

export default function Home(){
  const [audit,setAudit]=useState(null)
  const [marketing,setMarketing]=useState(null)

  async function runAudit(){
    const res = await fetch("http://localhost:3001/v1/audit",{method:"POST"})
    setAudit(await res.json())
  }

  async function genMarketing(){
    const res = await fetch("http://localhost:3001/v1/marketing",{method:"POST"})
    setMarketing(await res.json())
  }

  return (
    <div style={{padding:40}}>
      <h1>AI Business Platform v6</h1>

      <button onClick={runAudit}>Run Audit</button>

      {audit && (
        <div>
          <h2>Audit</h2>
          <pre>{JSON.stringify(audit,null,2)}</pre>
        </div>
      )}

      <button onClick={genMarketing}>Generate Marketing</button>

      {marketing && (
        <div>
          <h2>Marketing</h2>
          <pre>{JSON.stringify(marketing,null,2)}</pre>
        </div>
      )}
    </div>
  )
}
