
const express = require("express")
const app = express()
app.use(express.json())

app.post("/v1/audit", async (req,res)=>{
  res.json({
    score:8.5,
    risk:"medium",
    issues:["Example issue"],
    recommendations:["Refactor modules"]
  })
})

app.post("/v1/marketing", async (req,res)=>{
  res.json({
    landingPage:"Build better architecture instantly.",
    linkedin:"We just analyzed a repo with AI.",
    pricing:"$29/month"
  })
})

app.listen(3001,()=>console.log("API running"))
