
const fs = require("fs")

let portfolio = {
  capital: 10000,
  projects: [
    {name:"AI SaaS A", roi:2.5, status:"active"},
    {name:"AI SaaS B", roi:0.5, status:"active"}
  ]
}

function evaluateProjects(){
  for(const p of portfolio.projects){
    if(p.roi < 1){
      p.status = "killed"
      portfolio.capital += 500
    }
    else if(p.roi > 2){
      p.status = "scaled"
      portfolio.capital -= 1000
    }
  }
}

function createProject(){
  const newProject = {
    name: "AI Venture " + Date.now(),
    roi: Math.random()*3,
    status:"active"
  }
  portfolio.projects.push(newProject)
  portfolio.capital -= 1000
}

async function loop(){
  console.log("Self-investing portfolio running...")
  while(true){
    evaluateProjects()
    createProject()
    console.log("Portfolio:", portfolio)
    await new Promise(r=>setTimeout(r,10000))
  }
}

loop()
