
const express = require("express")
const app = express()

app.get("/portfolio",(req,res)=>{
  res.json({status:"running"})
})

app.listen(3001)
