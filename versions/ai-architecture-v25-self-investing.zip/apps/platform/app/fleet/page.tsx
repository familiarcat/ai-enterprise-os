
import Card from '../../components/shared/Card'

export default function Fleet(){
  return (
    <div>
      <h1>Fleet Admiral - Self Investing Portfolio</h1>
      <Card>Portfolio Optimization Running...</Card>
    </div>
  )
}
