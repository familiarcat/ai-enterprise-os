
export default function Home(){
  return <div>
    <h1>v25 Self-Investing Portfolio</h1>
    <a href="/fleet">Fleet Dashboard</a>
  </div>
}
