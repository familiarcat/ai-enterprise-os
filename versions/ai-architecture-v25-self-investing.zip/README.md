
# v25 Self-Investing AI Portfolio System

## Features
- Portfolio ROI optimization engine
- Capital allocation logic (auto-invest / kill / scale)
- Cross-project memory sharing (vector-ready)
- Autonomous project creation
- Fleet Admiral + Captain dashboards
- CI/CD ready (AWS + Vercel + Supabase)

Run:
cp .env.example .env
npm install
npm run dev
