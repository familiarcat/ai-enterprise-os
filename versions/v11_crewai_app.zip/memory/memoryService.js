
export class CrewMemory {
  store(data) {
    console.log("Memory stored:", data);
  }
}
