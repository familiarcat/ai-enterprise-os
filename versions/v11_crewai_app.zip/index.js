
import { CrewCaptain } from "./core/crewCaptain.js";

const captain = new CrewCaptain();

const result = await captain.handleTask("Build an AI system plan");

console.log("FINAL RESULT:", result);
