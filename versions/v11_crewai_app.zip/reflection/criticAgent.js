
export async function critiqueOutput(task, output) {
  return {
    score: 7,
    feedback: "Needs improvement"
  };
}
