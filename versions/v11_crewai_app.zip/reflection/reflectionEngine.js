
import { critiqueOutput } from "./criticAgent.js";

export async function executeWithReflection(task) {
  let result = `Executed task: ${task}`;

  const critique = await critiqueOutput(task, result);

  if (critique.score < 8) {
    result += " (improved)";
  }

  return { result, critique };
}
