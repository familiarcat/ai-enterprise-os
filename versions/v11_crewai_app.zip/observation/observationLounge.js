
export async function review(task, result) {
  console.log("Observation Lounge Review:", { task, result });
}
