
import { executeWithReflection } from "../reflection/reflectionEngine.js";
import { review } from "../observation/observationLounge.js";

export class CrewCaptain {
  async handleTask(task) {
    const result = await executeWithReflection(task);
    await review(task, result);
    return result;
  }
}
