
import fs from "fs"
import { chat } from "../../packages/openrouter/chat"
import { checkCache, storeCache } from "../../packages/cache/cache"
import { retrieve } from "../../packages/db/retrieval"
import { getTool } from "../tools/registry"

const agentsSpec = fs.readFileSync("agents.md", "utf-8")

export class Agent {
  constructor(role, prompt){
    this.role = role
    this.prompt = prompt
  }

  async run(input){
    const key = JSON.stringify(input)

    const cached = await checkCache(key)
    if(cached) return JSON.parse(cached.content).res

    const context = await retrieve(key)

    const decision = await chat([
      { role:"system", content: agentsSpec },
      { role:"system", content: "Role: " + this.role },
      { role:"system", content: this.prompt },
      { role:"system", content: "Context: " + JSON.stringify(context) },
      { role:"user", content: key }
    ])

    let result

    if(decision.content.includes("analyze_codebase")){
      const tool = getTool("analyze_codebase")
      result = await tool.handler(input)
    } else {
      result = decision.content
    }

    await storeCache(key, result)
    return result
  }
