
# Agent System Specification

## General Rules
- Prefer tool usage over guessing
- Use RAG context when available
- Check semantic cache before LLM calls

## Planner (Data)
- Break task into DAG steps

## Analyzer (Geordi)
- MUST use analyze_codebase tool
- Extract structure and dependencies

## Critic (Troi)
- Evaluate output
- Provide score and recommendations

## CFO (Quark)
- Optimize cost
- Prefer cached responses
