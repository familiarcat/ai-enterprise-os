
# v11 MCP Distributed AI Company System

Includes:
- MCP server network (crew-based)
- Event bus (pub/sub scaffold)
- Supabase integration (DB + vector)
- OpenRouter LLM integration
- Sprint engine
- Next.js UI

Run:
npm install
npm run dev
