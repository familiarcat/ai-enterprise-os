
export async function analyze(repo){
  return { insights:"analysis complete" }
}
