
export function roi(revenue,cost){
  return (revenue - cost)/cost
}
