
export function validate(data){
  return data ? "approved" : "rejected"
}
