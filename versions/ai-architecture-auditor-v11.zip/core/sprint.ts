
import { analyze } from "../mcp/geordi/server"
import { validate } from "../mcp/worf/server"
import { roi } from "../mcp/quark/server"

export async function runSprint(project){
  const analysis = await analyze(project.repo)
  const valid = validate(analysis)
  if(valid !== "approved") throw new Error("validation failed")

  const revenue = 10
  const cost = 0.05

  return {
    ...project,
    analysis,
    roi: roi(revenue,cost)
  }
}
