
export const eventBus = {
  publish: (event,data)=>console.log("EVENT:",event,data),
  subscribe: (event,handler)=>console.log("SUB:",event)
}
