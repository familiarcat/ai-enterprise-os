
const express = require("express")
const { runSprint } = require("../../core/sprint")

const app = express()
app.use(express.json())

app.post("/v1/sprint", async (req,res)=>{
  const result = await runSprint({repo:"repo"})
  res.json(result)
})

app.listen(3001,()=>console.log("API running"))
