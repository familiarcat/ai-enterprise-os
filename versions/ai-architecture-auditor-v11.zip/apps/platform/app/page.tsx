
'use client'
import { useState } from 'react'

export default function Home(){
  const [data,setData]=useState(null)

  async function run(){
    const res = await fetch("http://localhost:3001/v1/sprint",{method:"POST"})
    setData(await res.json())
  }

  return (
    <div style={{padding:40}}>
      <h1>v11 MCP Company</h1>
      <button onClick={run}>Run Sprint</button>
      {data && <pre>{JSON.stringify(data,null,2)}</pre>}
    </div>
  )
}
