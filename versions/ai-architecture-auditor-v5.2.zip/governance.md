
# AI Governance Model

## Core Principles
- No agent operates independently
- All outputs must pass validation (Worf)
- All plans originate from Planner (Data)
- Final approval required by Picard
- Cost evaluated by Quark
- Quality evaluated by Troi

## Pipeline Enforcement
1. planner → generate plan
2. analyzer → use tools
3. validator → must approve
4. critic → score + feedback
5. cfo → cost optimization
6. ceo → final decision
