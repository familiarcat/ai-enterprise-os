
import { runPipeline } from "./pipeline"

export async function runAudit(input){
  return runPipeline(input)
}
