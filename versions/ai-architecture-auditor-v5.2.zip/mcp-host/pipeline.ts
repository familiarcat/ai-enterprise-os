
import { agents } from "./agents"

export async function runPipeline(input){
  const context = {}

  context.plan = await agents.planner.run(input)
  context.analysis = await agents.analyzer.run({ ...input, plan: context.plan })

  context.validation = await agents.validator.run(context)
  if(context.validation !== "approved"){
    throw new Error("Validation failed")
  }

  context.critique = await agents.critic.run(context)
  context.cost = await agents.cfo.run(context)
  context.final = await agents.ceo.run(context)

  return context
}
