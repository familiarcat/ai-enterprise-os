
import fs from "fs"

const agentsSpec = fs.readFileSync("agents.md","utf-8")
const governanceSpec = fs.readFileSync("governance.md","utf-8")

export class Agent {
  constructor(role, handler){
    this.role = role
    this.handler = handler
  }

  async run(input){
    return this.handler(input, {
      role: this.role,
      agentsSpec,
      governanceSpec
    })
  }
