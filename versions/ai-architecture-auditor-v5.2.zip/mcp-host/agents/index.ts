
import { Agent } from "./base"

export const agents = {
  planner: new Agent("planner", async (input)=>"plan created"),
  analyzer: new Agent("analyzer", async (input)=>"analysis done"),
  validator: new Agent("validator", async ()=>"approved"),
  critic: new Agent("critic", async ()=>"score:8"),
  cfo: new Agent("cfo", async ()=>"cost optimized"),
  ceo: new Agent("ceo", async ()=>"approved final output")
}
