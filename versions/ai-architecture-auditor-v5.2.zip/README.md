
# v5.2 AI Auditor (Governance Enforced)

Includes:
- governance.md (rules)
- agents.md (roles)
- enforced role pipeline
- MCP-ready architecture

Run:
npm install
node apps/api/server.js
