
const express = require("express")
const { runAudit } = require("../../mcp-host/host")

const app = express()
app.use(express.json())

app.post("/v1/audit", async (req,res)=>{
  try{
    const result = await runAudit(req.body)
    res.json(result)
  }catch(e){
    res.status(500).json({error:e.message})
  }
})

app.listen(3001,()=>console.log("API running"))
