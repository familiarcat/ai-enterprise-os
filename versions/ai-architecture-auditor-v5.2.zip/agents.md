
# Agent Roles

Planner: break into DAG
Analyzer: must use tools
Validator: enforce correctness
Critic: evaluate quality
CFO: optimize cost
CEO: final approval
