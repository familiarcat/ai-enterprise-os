
const express = require("express")
const { runCycle } = require("../../core/orchestrator")

const app = express()
app.use(express.json())

app.post("/v1/run", async (req,res)=>{
  const result = await runCycle()
  res.json(result)
})

app.get("/health", (req,res)=>res.json({ ok: true }))

app.listen(3001,()=>console.log("API running on 3001"))
