
import Card from '../../shared/ui/Card'

export default function PortfolioDashboard({projects}){
  return (
    <div>
      <h3>Portfolio</h3>
      {projects.map(p=>(
        <Card key={p.id}>
          {p.name} — ROI: {p.roi}
        </Card>
      ))}
    </div>
  )
}
