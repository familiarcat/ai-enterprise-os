
import Card from '../../shared/ui/Card'

export default function DebateViewer({responses}){
  if(!responses) return null
  return (
    <div>
      <h3>Observation Lounge</h3>
      {responses.map((r,i)=>(
        <Card key={i}>
          <strong>{r.agent}</strong>: {r.text} (conf: {r.confidence})
        </Card>
      ))}
    </div>
  )
}
