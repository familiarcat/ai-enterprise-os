
'use client'
import { useState } from 'react'
import Button from '../shared/ui/Button'
import DebateViewer from '../components/debate/DebateViewer'

export default function Home(){
  const [data,setData]=useState(null)

  async function run(){
    const res = await fetch("http://localhost:3001/v1/run",{method:"POST"})
    setData(await res.json())
  }

  return (
    <div style={{padding:40}}>
      <h1>v14.1 AI Company Control Surface</h1>
      <Button onClick={run}>Run Autonomous Cycle</Button>

      {data && (
        <>
          <pre>{JSON.stringify(data.decision,null,2)}</pre>
          <DebateViewer responses={data?.responses} />
        </>
      )}
    </div>
  )
}
