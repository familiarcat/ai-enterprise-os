
export default function Button({children, ...props}){
  return <button style={{padding:8,border:'1px solid #ccc',borderRadius:8}} {...props}>{children}</button>
}
