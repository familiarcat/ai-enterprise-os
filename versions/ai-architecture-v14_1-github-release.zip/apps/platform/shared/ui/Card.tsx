
export default function Card({children}){
  return <div style={{border:'1px solid #eee',padding:12,borderRadius:12,marginBottom:12}}>{children}</div>
}
