
# AI Architecture v14.1 — Autonomous AI Company (GitHub Release)

> Distributed MCP mesh + Observation Lounge + Weighted Consensus + RAG-ready Memory + Next.js Control Surface

## Highlights
- 🖖 Full Crew MCP services (Picard, Data, Geordi, Worf, Troi, Quark, Riker, Crusher)
- 🧠 Observation Lounge (debate → weighted consensus → decision)
- 💾 Memory (Supabase-ready + vector RAG stubs)
- 🔗 Event Bus (Redis Pub/Sub)
- 🏢 Portfolio orchestration (multi-project)
- 🖥 Next.js UI (shared/ + components/ with Observation Lounge, Debate Viewer, Portfolio)

## Quick Start
```bash
cp .env.example .env
npm install
npm run dev
```

Open:
- UI: http://localhost:3000
- API: http://localhost:3001

## Structure
- apps/api — Express API
- apps/platform — Next.js UI
- core — orchestration, consensus, observation lounge
- mcp — distributed services (HTTP)
- packages — llm, memory, db
- infra — env + supabase schema

## Notes
- Replace stubs with real tools, RAG, and billing for production.
- See docs/ for architecture and prompts.
