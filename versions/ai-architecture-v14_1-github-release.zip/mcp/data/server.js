
const express = require("express")
const app = express()
app.use(express.json())

app.post("/", (req,res)=>res.json({ agent: "data", ok: true, input: req.body }))

app.listen(4101,()=>console.log("data MCP running on 4101"))
