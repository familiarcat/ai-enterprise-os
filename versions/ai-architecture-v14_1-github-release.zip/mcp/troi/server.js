
const express = require("express")
const app = express()
app.use(express.json())

app.post("/", (req,res)=>res.json({ agent: "troi", ok: true, input: req.body }))

app.listen(4104,()=>console.log("troi MCP running on 4104"))
