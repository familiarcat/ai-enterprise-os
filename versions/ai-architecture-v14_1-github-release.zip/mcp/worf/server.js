
const express = require("express")
const app = express()
app.use(express.json())

app.post("/", (req,res)=>res.json({ agent: "worf", ok: true, input: req.body }))

app.listen(4103,()=>console.log("worf MCP running on 4103"))
