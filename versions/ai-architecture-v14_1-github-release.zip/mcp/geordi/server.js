
const express = require("express")
const app = express()
app.use(express.json())

app.post("/", (req,res)=>res.json({ agent: "geordi", ok: true, input: req.body }))

app.listen(4102,()=>console.log("geordi MCP running on 4102"))
