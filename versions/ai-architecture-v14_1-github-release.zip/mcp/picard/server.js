
const express = require("express")
const app = express()
app.use(express.json())

app.post("/", (req,res)=>res.json({ agent: "picard", ok: true, input: req.body }))

app.listen(4100,()=>console.log("picard MCP running on 4100"))
