
const express = require("express")
const app = express()
app.use(express.json())

app.post("/", (req,res)=>res.json({ agent: "crusher", ok: true, input: req.body }))

app.listen(4107,()=>console.log("crusher MCP running on 4107"))
