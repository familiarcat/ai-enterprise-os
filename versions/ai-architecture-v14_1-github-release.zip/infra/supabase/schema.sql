
create table if not exists projects (
  id uuid primary key,
  name text,
  created_at timestamp default now()
);

create table if not exists debates (
  id uuid primary key,
  mission text,
  decision jsonb,
  created_at timestamp default now()
);
