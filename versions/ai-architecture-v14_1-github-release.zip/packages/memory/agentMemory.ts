
export async function retrieveMemory({ agent, topic }){
  return [{ agent, topic, note: "historical insight placeholder" }]
}
