
import { deliberate } from "./observationLounge"
import { generateMission } from "./missionGenerator"
import { logDebate } from "./debateLog"

export async function runCycle(){
  const mission = await generateMission()

  const crew = {
    data: { plan: async c => ({ agent:"data", confidence:0.9, text:"plan" }) },
    geordi: { analyze: async c => ({ agent:"geordi", confidence:0.8, text:"analysis" }) },
    worf: { validate: async c => ({ agent:"worf", confidence:0.95, text:"approved" }) },
    troi: { evaluate: async c => ({ agent:"troi", confidence:0.7, text:"quality ok" }) },
    quark: { assess: async c => ({ agent:"quark", confidence:0.85, text:"roi strong" }) }
  }

  const { responses, decision } = await deliberate(mission, crew)
  logDebate({ mission, responses, decision })
  return { mission, decision }
}
