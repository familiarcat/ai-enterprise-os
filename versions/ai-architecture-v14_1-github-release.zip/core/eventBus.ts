
import Redis from "ioredis"
const redis = new Redis(process.env.REDIS_URL)

export const eventBus = {
  publish: async (event, data) => {
    await redis.publish(event, JSON.stringify(data))
  },
  subscribe: (event, handler) => {
    const sub = new Redis(process.env.REDIS_URL)
    sub.subscribe(event)
    sub.on("message", (_, message) => handler(JSON.parse(message)))
  }
}
