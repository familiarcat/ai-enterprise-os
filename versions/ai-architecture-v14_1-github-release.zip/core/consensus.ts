
export const weights = {
  picard: 1.5, data: 1.2, geordi: 1.2, worf: 1.3,
  troi: 1.1, quark: 1.4, riker: 1.0, crusher: 1.1
}

export function weightedConsensus(responses){
  return responses
    .map(r => ({...r, score: (r.confidence||1)*(weights[r.agent]||1)}))
    .sort((a,b)=>b.score-a.score)[0]
}
