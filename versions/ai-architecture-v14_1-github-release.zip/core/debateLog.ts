
export function logDebate(entry){
  console.log("DEBATE LOG:", JSON.stringify(entry, null, 2))
}
