
export async function generateMission(){
  return { mission: "Identify highest ROI optimization across portfolio" }
}
