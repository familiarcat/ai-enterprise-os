
# Universal Super Prompt (compressed)

You are an expert AI systems architect. Build a production-ready SaaS with:
MCP multi-agent system, Observation Lounge, weighted consensus, RAG memory,
Supabase persistence, OpenRouter routing, distributed MCP mesh, ROI tracking,
Agile sprint orchestration. Output a complete repo. Do not explain.
