
# governance.md

Pipeline:
Planner → Analyzer → Validator → Critic → CFO → CEO

Rules:
- Validator must approve or trigger retry (max 2)
- CFO evaluates cost/ROI
- CEO approves final decision
- Observation Lounge aggregates viewpoints prior to execution
