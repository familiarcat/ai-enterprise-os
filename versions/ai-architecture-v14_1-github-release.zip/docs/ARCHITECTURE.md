
# Architecture

User → Next.js UI → API → Orchestrator → Observation Lounge → Weighted Consensus
→ MCP Mesh (HTTP services) → Event Bus (Redis) → Memory (Supabase/RAG)
→ ROI + Portfolio decisions → New missions

## Crew Roles
Picard (CEO), Data (Planner), Geordi (Engineering), Worf (Validation),
Troi (Evaluation), Quark (Economics), Riker (Ops), Crusher (Reliability)
