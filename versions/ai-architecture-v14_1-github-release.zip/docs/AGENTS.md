
# agents.md

- Picard: final decision authority
- Data: DAG planning
- Geordi: tool execution
- Worf: validation & risk
- Troi: qualitative evaluation
- Quark: ROI & pricing
- Riker: execution & SLAs
- Crusher: reliability & recovery

All agents can contribute in Observation Lounge; assigned agents execute.
