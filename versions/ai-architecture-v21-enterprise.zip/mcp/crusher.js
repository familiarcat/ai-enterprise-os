
const express = require("express")
const app = express()
app.use(express.json())

app.post("/", (req,res)=>{
  res.json({agent:"crusher",output:"processed",input:req.body})
})

app.listen(4107, ()=>console.log("crusher running on 4107"))
