
const express = require("express")
const app = express()
app.use(express.json())

app.post("/", (req,res)=>{
  res.json({agent:"troi",output:"processed",input:req.body})
})

app.listen(4104, ()=>console.log("troi running on 4104"))
