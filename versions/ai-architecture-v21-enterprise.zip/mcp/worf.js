
const express = require("express")
const app = express()
app.use(express.json())

app.post("/", (req,res)=>{
  res.json({agent:"worf",output:"processed",input:req.body})
})

app.listen(4103, ()=>console.log("worf running on 4103"))
