
const express = require("express")
const app = express()
app.use(express.json())

app.post("/", (req,res)=>{
  res.json({agent:"picard",output:"processed",input:req.body})
})

app.listen(4108, ()=>console.log("picard running on 4108"))
