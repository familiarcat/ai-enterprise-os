
const express = require("express")
const app = express()
app.use(express.json())

app.post("/", (req,res)=>{
  res.json({agent:"data",output:"processed",input:req.body})
})

app.listen(4102, ()=>console.log("data running on 4102"))
