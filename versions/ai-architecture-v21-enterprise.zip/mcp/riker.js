
const express = require("express")
const app = express()
app.use(express.json())

app.post("/", (req,res)=>{
  res.json({agent:"riker",output:"processed",input:req.body})
})

app.listen(4106, ()=>console.log("riker running on 4106"))
