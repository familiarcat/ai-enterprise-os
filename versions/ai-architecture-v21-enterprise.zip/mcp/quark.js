
const express = require("express")
const app = express()
app.use(express.json())

app.post("/", (req,res)=>{
  res.json({agent:"quark",output:"processed",input:req.body})
})

app.listen(4105, ()=>console.log("quark running on 4105"))
