
const express = require("express")
const app = express()
app.use(express.json())

app.post("/", (req,res)=>{
  res.json({agent:"geordi",output:"processed",input:req.body})
})

app.listen(4101, ()=>console.log("geordi running on 4101"))
