
let registry = {}

function register(name, url, capabilities){
  registry[name] = { url, capabilities }
}

function list(){
  return registry
}

module.exports = { register, list }
