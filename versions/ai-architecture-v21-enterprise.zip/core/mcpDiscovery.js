
const { list } = require("./mcpRegistry")

async function discover(task){
  const services = list()
  return Object.entries(services)
}

module.exports = { discover }
