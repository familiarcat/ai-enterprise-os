
const axios = require("axios")
const { discover } = require("./mcpDiscovery")
const { evaluateROI } = require("../domains/economics/engine")

async function call(url, data){
  try{
    const res = await axios.post(url, data)
    return res.data
  }catch(e){
    return {error:true}
  }
}

async function runEnterpriseMission(objective){
  const services = await discover(objective)
  const results = []

  for(const [name, svc] of services){
    const res = await call(svc.url, {objective})
    results.push({name, res})
  }

  const economics = evaluateROI(results)

  return {
    objective,
    servicesUsed: services.map(([n])=>n),
    results,
    economics
  }
}

module.exports = { runEnterpriseMission }
