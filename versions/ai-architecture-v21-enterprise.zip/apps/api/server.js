
const express = require("express")
const { runEnterpriseMission } = require("../../core/orchestrator")

const app = express()
app.use(express.json())

app.post("/mission", async (req,res)=>{
  const result = await runEnterpriseMission(req.body.objective)
  res.json(result)
})

app.listen(3001, ()=>console.log("API running"))
