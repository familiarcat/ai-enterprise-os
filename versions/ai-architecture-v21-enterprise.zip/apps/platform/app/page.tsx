
'use client'
import {useState} from 'react'

export default function Home(){
 const [d,setD]=useState(null)

 async function run(){
  const res = await fetch("http://localhost:3001/mission",{
    method:"POST",
    headers:{"Content-Type":"application/json"},
    body:JSON.stringify({objective:"Run AI enterprise"})
  })
  setD(await res.json())
 }

 return (
  <div style={{padding:40}}>
    <h1>v21 Enterprise AI</h1>
    <button onClick={run}>Run Mission</button>
    <pre>{JSON.stringify(d,null,2)}</pre>
  </div>
 )
}
