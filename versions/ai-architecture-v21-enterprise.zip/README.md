
# v21 Autonomous AI Enterprise System

## Overview
Domain-Driven Design + MCP Mesh + Economic Engine

## Domains
- projects
- missions
- agents
- memory
- economics
- governance
- deployment

## Deployment
GitHub → AWS (ECS + Secrets) → Vercel (UI)

## Run
npm install
npm run dev
