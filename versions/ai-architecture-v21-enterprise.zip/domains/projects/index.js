
// projects domain service
module.exports = {
  name: "projects",
  execute: async (input) => ({ domain: "projects", input })
}
