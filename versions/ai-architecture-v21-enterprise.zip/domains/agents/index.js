
// agents domain service
module.exports = {
  name: "agents",
  execute: async (input) => ({ domain: "agents", input })
}
