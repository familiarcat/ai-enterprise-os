
// governance domain service
module.exports = {
  name: "governance",
  execute: async (input) => ({ domain: "governance", input })
}
