
// deployment domain service
module.exports = {
  name: "deployment",
  execute: async (input) => ({ domain: "deployment", input })
}
