
// missions domain service
module.exports = {
  name: "missions",
  execute: async (input) => ({ domain: "missions", input })
}
