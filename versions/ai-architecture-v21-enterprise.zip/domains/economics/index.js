
// economics domain service
module.exports = {
  name: "economics",
  execute: async (input) => ({ domain: "economics", input })
}
