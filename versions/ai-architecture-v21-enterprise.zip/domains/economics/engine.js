
function evaluateROI(result){
  return {
    revenue: Math.random()*1000,
    cost: Math.random()*300,
    score: Math.random()*5
  }
}

module.exports = { evaluateROI }
