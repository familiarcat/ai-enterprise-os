
// memory domain service
module.exports = {
  name: "memory",
  execute: async (input) => ({ domain: "memory", input })
}
