
const express = require("express")
const { runPortfolio } = require("../../core/orchestrator")

const app = express()
app.use(express.json())

app.post("/v1/portfolio", async (req,res)=>{
  const projects = req.body.projects || [{id:1,repo:"repoA"},{id:2,repo:"repoB"}]
  const result = await runPortfolio(projects)
  res.json(result)
})

app.listen(3001,()=>console.log("API running"))
