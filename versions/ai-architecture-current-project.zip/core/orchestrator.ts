
import axios from "axios"

export async function runProject(project){
  const analysis = await axios.post("http://localhost:4001/analyze",{repo:project.repo})
  const validation = await axios.post("http://localhost:4002/validate",analysis.data)

  if(validation.data.status !== "approved"){
    throw new Error("Validation failed")
  }

  const roi = await axios.post("http://localhost:4003/roi",{revenue:10,cost:0.05})

  return {
    ...project,
    analysis: analysis.data,
    roi: roi.data.roi
  }
}

export async function runPortfolio(projects){
  const results = []
  for(const p of projects){
    results.push(await runProject(p))
  }
  return results
}
