
const express = require("express")
const app = express()
app.use(express.json())

app.post("/analyze", (req,res)=>{
  res.json({ insights:"deep analysis", score:8.8 })
})

app.listen(4001,()=>console.log("Geordi MCP running"))
