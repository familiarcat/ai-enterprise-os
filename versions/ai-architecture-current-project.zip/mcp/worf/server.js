
const express = require("express")
const app = express()
app.use(express.json())

app.post("/validate",(req,res)=>{
  res.json({ status:"approved" })
})

app.listen(4002,()=>console.log("Worf MCP running"))
