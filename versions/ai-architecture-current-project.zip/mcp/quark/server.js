
const express = require("express")
const app = express()
app.use(express.json())

app.post("/roi",(req,res)=>{
  const { revenue, cost } = req.body
  res.json({ roi:(revenue-cost)/cost })
})

app.listen(4003,()=>console.log("Quark MCP running"))
