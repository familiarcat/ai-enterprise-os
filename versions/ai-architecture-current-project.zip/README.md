
# v12 Distributed MCP Mesh AI Company

Features:
- Distributed MCP services (HTTP-based)
- Real event bus (Redis Pub/Sub)
- Multi-project orchestration engine
- Supabase memory layer
- OpenRouter LLM integration
- Next.js platform UI

Run:
npm install
npm run dev
