
'use client'
import { useEffect, useState } from 'react'

export default function Home(){
  const [projects,setProjects]=useState([])

  async function load(){
    const res = await fetch("/api/projects")
    setProjects(await res.json())
  }

  useEffect(()=>{ load() },[])

  return (
    <div style={{padding:40}}>
      <h1>v8 SaaS Platform</h1>
      <ul>
        {projects.map(p=>(
          <li key={p.id}>{p.name}</li>
        ))}
      </ul>
    </div>
  )
}
