
const express = require("express")
const app = express()
app.use(express.json())

app.post("/v1/audit", async (req,res)=>{
  // placeholder for MCP pipeline
  res.json({
    score:8.7,
    risk:"low",
    cost:0.05,
    revenue:10
  })
})

app.listen(3001,()=>console.log("API running"))
