
create table users (
  id uuid primary key,
  email text
);

create table projects (
  id uuid primary key,
  user_id uuid,
  name text,
  repo_url text
);

create table audits (
  id uuid primary key,
  project_id uuid,
  score float,
  risk text,
  cost float,
  revenue float,
  created_at timestamp default now()
);
