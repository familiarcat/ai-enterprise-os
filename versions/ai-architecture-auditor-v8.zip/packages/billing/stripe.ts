
export function chargeUser(userId, amount){
  console.log("Charging", userId, amount)
}
