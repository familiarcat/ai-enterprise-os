
# AI Architecture Auditor v8 (Production SaaS)

Features:
- Supabase Auth + DB schema
- Project + Audit + ROI persistence
- Stripe billing hooks
- Next.js platform (projects + detail pages)
- API ready for deployment (Express)
- MCP-ready integration points

Run:
npm install
npm run dev:api
npm run dev:web
