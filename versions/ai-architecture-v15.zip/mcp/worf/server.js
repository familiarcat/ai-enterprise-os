
const express=require("express")
const app=express()
app.use(express.json())
app.post("/",(req,res)=>res.json({agent:"worf",ok:true}))
app.listen(4102,()=>console.log("worf running"))
