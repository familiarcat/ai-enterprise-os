
const express=require("express")
const app=express()
app.use(express.json())
app.post("/",(req,res)=>res.json({agent:"quark",ok:true}))
app.listen(4103,()=>console.log("quark running"))
