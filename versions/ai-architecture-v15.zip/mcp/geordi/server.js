
const express=require("express")
const app=express()
app.use(express.json())
app.post("/",(req,res)=>res.json({agent:"geordi",ok:true}))
app.listen(4101,()=>console.log("geordi running"))
