
export default function DebateViewer({responses}){
 if(!responses) return null
 return <div>{responses.map((r,i)=><div key={i}>{r.agent}:{r.text}</div>)}</div>
}
