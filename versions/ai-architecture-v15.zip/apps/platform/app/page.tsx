
'use client'
import {useState} from 'react'
import DebateViewer from '../components/debate/DebateViewer'
export default function Home(){
 const [d,setD]=useState(null)
 async function run(){const r=await fetch("http://localhost:3001/v1/run",{method:"POST"});setD(await r.json())}
 return <div><button onClick={run}>Run</button><DebateViewer responses={d?.responses}/></div>
}
