
provider "aws" { region = "us-east-2" }
resource "aws_ecs_cluster" "main" { name="mcp-cluster" }
