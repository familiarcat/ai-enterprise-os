
import Redis from "ioredis"
const redis = new Redis(process.env.REDIS_URL)
export const eventBus = {
  publish:(e,d)=>redis.publish(e,JSON.stringify(d)),
  subscribe:(e,h)=>{const s=new Redis(process.env.REDIS_URL);s.subscribe(e);s.on("message",(_,m)=>h(JSON.parse(m)))}
}
