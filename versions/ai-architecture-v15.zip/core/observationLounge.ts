
import { weightedConsensus } from "./consensus"

export async function deliberate(context, crew){
  const responses = await Promise.all([
    crew.data.plan(context),
    crew.geordi.analyze(context),
    crew.worf.validate(context),
    crew.quark.assess(context)
  ])
  const decision = weightedConsensus(responses)
  return {responses, decision}
}
