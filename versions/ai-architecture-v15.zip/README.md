
# v15 AI Company Platform

## Overview
Distributed MCP mesh with Observation Lounge (consensus), memory (RAG-ready),
Vercel UI, AWS backend, Redis event bus, Supabase persistence, CI/CD + Terraform.

## Quickstart (local)
cp .env.example .env
npm install
npm run dev

## Deploy
./scripts/deploy-all.sh

## Architecture
Vercel(UI) → API → Orchestrator → Observation Lounge → MCP Mesh(AWS ECS)
→ Redis → Supabase
