
async function runPortfolio(portfolio){
  for(const project of portfolio.projects){
    console.log("Running project:", project.name)
  }
}

module.exports = { runPortfolio }
