
# v24 Autonomous AI Portfolio System

Features:
- Fleet Admiral Dashboard (portfolio-level control)
- Captain Dashboard (per-project control)
- Shared React component system
- Portfolio orchestration engine
- Multi-project Supabase schema
- Compatible with AWS + Vercel CI/CD

Run:
cp .env.example .env
npm install
npm run dev
