
const express = require("express")
const app = express()

app.use(express.json())

app.get("/portfolio", (req,res)=>{
  res.json({projects:[]})
})

app.listen(3001)
