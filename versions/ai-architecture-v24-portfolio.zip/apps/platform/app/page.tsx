
export default function Home(){
  return <div>
    <h1>v24 Portfolio System</h1>
    <a href="/fleet">Fleet Dashboard</a>
  </div>
}
