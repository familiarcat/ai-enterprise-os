
import Card from '../../components/shared/Card'
import Chart from '../../components/shared/Chart'

export default function Fleet(){
  return (
    <div>
      <h1>Fleet Admiral Dashboard</h1>
      <Card>
        <Chart data={{roi: "portfolio"}} />
      </Card>
    </div>
  )
}
