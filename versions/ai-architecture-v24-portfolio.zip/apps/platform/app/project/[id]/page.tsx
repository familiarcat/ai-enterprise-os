
import Card from '../../../components/shared/Card'
import Chart from '../../../components/shared/Chart'

export default function Project(){
  return (
    <div>
      <h1>Captain Dashboard</h1>
      <Card>
        <Chart data={{roi: "project"}} />
      </Card>
    </div>
  )
}
