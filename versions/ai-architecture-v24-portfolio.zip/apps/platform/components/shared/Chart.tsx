
export default function Chart({data}){
  return <pre>{JSON.stringify(data,null,2)}</pre>
}
