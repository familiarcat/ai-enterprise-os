
export default function Card({children}){
  return <div style={{border:'1px solid #ccc',padding:16}}>{children}</div>
}
