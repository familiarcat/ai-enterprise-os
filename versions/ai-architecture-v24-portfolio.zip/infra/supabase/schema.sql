
create table portfolios (
  id uuid primary key,
  name text,
  created_at timestamp default now()
);

create table projects (
  id uuid primary key,
  portfolio_id uuid,
  name text,
  owner_id text,
  status text,
  created_at timestamp default now()
);

create table missions (
  id uuid primary key,
  project_id uuid,
  objective text,
  status text,
  result jsonb,
  created_at timestamp default now()
);

create table roi_metrics (
  project_id uuid,
  revenue float,
  cost float,
  score float
);
