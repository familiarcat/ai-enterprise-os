
const express = require("express")
const app = express()
app.use(express.json())

app.post("/", (req,res)=>{
  res.json({ agent: "picard", response: "picard processed input" })
})

app.listen(4000,()=>console.log("picard MCP running"))
