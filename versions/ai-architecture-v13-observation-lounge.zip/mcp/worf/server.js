
const express = require("express")
const app = express()
app.use(express.json())

app.post("/", (req,res)=>{
  res.json({ agent: "worf", response: "worf processed input" })
})

app.listen(4003,()=>console.log("worf MCP running"))
