
const express = require("express")
const app = express()
app.use(express.json())

app.post("/", (req,res)=>{
  res.json({ agent: "crusher", response: "crusher processed input" })
})

app.listen(4007,()=>console.log("crusher MCP running"))
