
const express = require("express")
const app = express()
app.use(express.json())

app.post("/", (req,res)=>{
  res.json({ agent: "quark", response: "quark processed input" })
})

app.listen(4005,()=>console.log("quark MCP running"))
