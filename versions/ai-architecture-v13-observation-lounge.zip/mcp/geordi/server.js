
const express = require("express")
const app = express()
app.use(express.json())

app.post("/", (req,res)=>{
  res.json({ agent: "geordi", response: "geordi processed input" })
})

app.listen(4002,()=>console.log("geordi MCP running"))
