
const express = require("express")
const app = express()
app.use(express.json())

app.post("/", (req,res)=>{
  res.json({ agent: "riker", response: "riker processed input" })
})

app.listen(4006,()=>console.log("riker MCP running"))
