
const express = require("express")
const app = express()
app.use(express.json())

app.post("/", (req,res)=>{
  res.json({ agent: "data", response: "data processed input" })
})

app.listen(4001,()=>console.log("data MCP running"))
