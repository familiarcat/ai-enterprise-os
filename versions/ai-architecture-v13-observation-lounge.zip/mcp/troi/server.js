
const express = require("express")
const app = express()
app.use(express.json())

app.post("/", (req,res)=>{
  res.json({ agent: "troi", response: "troi processed input" })
})

app.listen(4004,()=>console.log("troi MCP running"))
