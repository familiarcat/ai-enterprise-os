
# v13 Observation Lounge AI Company System

Features:
- Full crew MCP servers (Picard, Data, Geordi, Worf, Troi, Quark, Riker, Crusher)
- Observation Lounge consensus engine
- Debate + synthesis layer (OpenRouter)
- Memory-driven agents (Supabase-ready)
- Distributed MCP mesh
- Multi-project orchestration

Run:
npm install
npm run dev
