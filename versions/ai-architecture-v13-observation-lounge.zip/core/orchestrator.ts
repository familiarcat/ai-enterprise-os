
import axios from "axios"
import { deliberate } from "./observationLounge"

export async function runMission(context){
  const crew = {
    data: { plan: async (c)=> (await axios.post("http://localhost:4001/",c)).data },
    geordi: { analyze: async (c)=> (await axios.post("http://localhost:4002/",c)).data },
    worf: { validate: async (c)=> (await axios.post("http://localhost:4003/",c)).data },
    troi: { evaluate: async (c)=> (await axios.post("http://localhost:4004/",c)).data },
    quark: { assess: async (c)=> (await axios.post("http://localhost:4005/",c)).data }
  }

  const decision = await deliberate(context, crew)

  return decision
}
