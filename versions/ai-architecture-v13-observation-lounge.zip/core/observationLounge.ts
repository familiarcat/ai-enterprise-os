
import { chat } from "../packages/llm/openrouter"

export async function deliberate(context, crew) {
  const responses = await Promise.all([
    crew.data.plan(context),
    crew.geordi.analyze(context),
    crew.worf.validate(context),
    crew.troi.evaluate(context),
    crew.quark.assess(context)
  ])

  const consensus = await chat([
    { role: "system", content: "Synthesize crew viewpoints into a single decision" },
    { role: "user", content: JSON.stringify(responses) }
  ])

  return consensus
}
