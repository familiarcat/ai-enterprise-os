
const express = require("express")
const { runMission } = require("../../core/orchestrator")

const app = express()
app.use(express.json())

app.post("/v1/mission", async (req,res)=>{
  const result = await runMission(req.body)
  res.json({ decision: result })
})

app.listen(3001,()=>console.log("API running"))
