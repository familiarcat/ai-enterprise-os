
'use client'
import { useState } from 'react'

export default function Home(){
  const [data,setData]=useState(null)

  async function run(){
    const res = await fetch("http://localhost:3001/v1/mission",{
      method:"POST",
      headers:{ "Content-Type":"application/json" },
      body: JSON.stringify({ mission:"Optimize SaaS pricing" })
    })
    setData(await res.json())
  }

  return (
    <div style={{padding:40}}>
      <h1>v13 Observation Lounge System</h1>
      <button onClick={run}>Run Mission</button>
      {data && <pre>{JSON.stringify(data,null,2)}</pre>}
    </div>
  )
}
