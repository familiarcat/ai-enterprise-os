import axios from "axios"
export async function routeRequest(payload){
  try { return await axios.post(process.env.PRIMARY_API,payload)}
  catch { return await axios.post(process.env.FAILOVER_API,payload)}
}
