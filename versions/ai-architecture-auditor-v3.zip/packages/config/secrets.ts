import AWS from "aws-sdk"
const sm = new AWS.SecretsManager({region:process.env.AWS_REGION})
export async function loadSecrets(){
  const res = await sm.getSecretValue({SecretId:"ai-auditor-secrets"}).promise()
  Object.assign(process.env, JSON.parse(res.SecretString))
}
