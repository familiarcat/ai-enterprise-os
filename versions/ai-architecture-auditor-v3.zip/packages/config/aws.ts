export const AWS_CONFIG = {
  REGION: process.env.AWS_REGION,
  PRIMARY: process.env.AWS_PRIMARY_REGION,
  FAILOVER: process.env.AWS_FAILOVER_REGION
}
