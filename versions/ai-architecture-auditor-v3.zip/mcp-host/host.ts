export async function runAudit(input){
  return {summary:"v3 system running", score:8}
}
