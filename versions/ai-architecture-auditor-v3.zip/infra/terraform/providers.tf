provider "aws" {
  alias  = "primary"
  region = var.primary_region
}
provider "aws" {
  alias  = "failover"
  region = var.failover_region
}
