resource "aws_ecs_cluster" "primary" {
  provider = aws.primary
  name = "mcp-primary"
}
resource "aws_ecs_cluster" "failover" {
  provider = aws.failover
  name = "mcp-failover"
}
