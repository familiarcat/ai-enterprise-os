variable "primary_region" {}
variable "failover_region" {}
