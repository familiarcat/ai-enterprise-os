const AWS = require("aws-sdk")
require("dotenv").config()
const sm = new AWS.SecretsManager({ region: process.env.AWS_REGION })
async function run(){
  await sm.putSecretValue({
    SecretId:"ai-auditor-secrets",
    SecretString: JSON.stringify(process.env)
  }).promise()
  console.log("pushed")
}
run()
