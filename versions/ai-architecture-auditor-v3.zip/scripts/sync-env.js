const { execSync } = require("child_process")
execSync("node scripts/check-env.js",{stdio:"inherit"})
execSync("node scripts/push-secrets.js",{stdio:"inherit"})
console.log("synced")
