require("dotenv").config()
const required = ["AWS_REGION","OPENROUTER_API_KEY","STRIPE_SECRET_KEY"]
const missing = required.filter(k => !process.env[k])
if (missing.length) { console.error(missing); process.exit(1) }
console.log("OK")
